import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import "antd/dist/antd.css"
import {Row,Col} from "antd";

import TopNav from "./components/navigation/topnav"
import BottomNav from "./components/navigation/bottomnav"
import Search from "./components/search/search"

import FilterTag from "./components/search/filtertag"
import FilterPage from "./components/search/filterpage"
import MainViewPage from "./components/mainviewpage"


import {connect} from 'react-redux'
import PropTypes from 'prop-types'







class App extends Component{


	render(){


// console.log('to view data '+ (!!Object.keys(toViewData).length === false) )

// console.log('to view data length '+  (!!Object.keys({toViewData}).length === !!Object.keys({}).length)
// )

		return(

			<>

<Search></Search>
<FilterTag></FilterTag>


 <Row gutter={[12,12]}>
<Col span={5} className="filterviewpage">
<FilterPage></FilterPage>
</Col>


<Col span={19} className='mainviewpage'>

<MainViewPage></MainViewPage>
</Col>

</Row>






</>

		)
			
	}
}

export default App;




// App.propTypes = {

//    	toViewData:PropTypes.object,

	
// }