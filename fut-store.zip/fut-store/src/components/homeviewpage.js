
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import "antd/dist/antd.css"
import {Empty,List,Pagination} from "antd";
import {LoadingOutlined} from '@ant-design/icons';
import {connect} from 'react-redux'
import PropTypes from 'prop-types'
import {withRouter} from 'react-router-dom'
import {updateAjaxRoute} from '../actions/ajaxroute'
import {search} from "../actions/search"
import ListViewRent from "./contrib/rentview"




// const mapDispatchToProps=dispatch =>({
//     onclick:f=>f
//     })
    
    const mapStateToProps= (state, props)=>({
    
        filtername:state.filterData.filtername,
        maindata:state.MainData,
        routeStatus:state.ajaxRoute.status,
        searchFilterVal:state.searchData,
       
    })

    


  class HomeViewPage extends Component{
        
    
    constructor(props){
    super(props)

    this.state = {
 
      }

  
}



UNSAFE_componentWillMount(){
  document.title = "Welcome | beBO.com"

}



    
    render(){

const {routeStatus, filtername,maindata,history} = this.props;



      return (
<div className="homeview" >

{routeStatus ? <p>Loading <LoadingOutlined spin></LoadingOutlined></p>
: <div>

home
</div>}

        </div>

      )

    }
  }

  
 
  

  
  
  export default withRouter(connect(mapStateToProps,{updateAjaxRoute,search})(HomeViewPage))

  HomeViewPage.propTypes = {
 
           
      maindata:PropTypes.array.isRequired,
      search:PropTypes.func.isRequired,
      updateAjaxRoute:PropTypes.func.isRequired,
      routeStatus:PropTypes.bool.isRequired,
      searchFilterVal:PropTypes.object.isRequired,
     
     
      
  }