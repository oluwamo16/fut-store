
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import {withRouter} from 'react-router-dom'
import "antd/dist/antd.css"
import {Button} from "antd";
import {HomeOutlined} from '@ant-design/icons';
import {connect} from 'react-redux'
import PropTypes from 'prop-types'

import {dailyDeals,setSearchPref} from "../../actions/search"
import {updateAjaxRoute} from '../../actions/ajaxroute'
import {setToHome} from '../../actions/contrib'
import {get_current_address} from "../../actions/location"
import {setFilter,handleFilterClick} from "../../actions/filter"




const mapStateToProps= (state, props)=>({
    
    user:state.User,
    profile:state.DashboardData.profile,
    myProperty:state.DashboardData.myProperty,
    mainData:state.MainData,
})




class Home  extends Component{

        clearFilter=(e)=>{

// const newValue = ''


    this.props.updateAjaxRoute(true)
this.props.setToHome(true);
     this.props.dailyDeals('')

this.props.setSearchPref("")
this.props.history.push('/')

}


        
    render(){

        const {history,type,label}=this.props;
        // console.log("profile-dash-data: "+Object.keys(profile))

        return(


<Button icon={<HomeOutlined></HomeOutlined>} 
type={type ? type:'ghost'} style={{'border-radius': '0px'}} className="home-new" onClick={this.clearFilter}
>{label ? label :Home}</Button> 

        )
    }
}


export default withRouter(connect(mapStateToProps, {setFilter,handleFilterClick,setSearchPref,updateAjaxRoute,get_current_address,dailyDeals,setToHome})(Home))

Home.propTypes = {

   updateAjaxRoute:PropTypes.func.isRequired,
    get_current_address:PropTypes.func.isRequired,
}
