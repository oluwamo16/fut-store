
import React, { Component } from 'react';
import ReactDOM from 'react-dom';

import "antd/dist/antd.css"
import {Menu, Button, Avatar,Tag,Typography} from "antd";
import {MenuOutlined,UserOutlined, ShoppingCartOutlined } from '@ant-design/icons';
import logo192 from "../../statics/logo192.png";
import "../../css/topnav.css"
import {connect} from 'react-redux'
import PropTypes from 'prop-types'
import {withRouter} from 'react-router-dom'
import {getCartLen,setCartLen} from "../../actions/cart"
import {BASE_IMG_URL} from '../../settings'
import {setToHome} from '../../actions/contrib'
import {dailyDeals} from "../../actions/search"
import {updateAjaxRoute} from '../../actions/ajaxroute'
import {get_current_address} from "../../actions/location"





const mapDispatchToProps=dispatch =>({
    onclick:f=>f
    })
    
    const mapStateToProps= (state, props)=>({
    
        user:state.User,
        cartDataLen:state.cartLen
    })

    


  class TopNav extends Component{

      constructor(props){
    super(props)
    this.state = {
    image:'',
    moremenu:false,
    }
  }

  componentDidMount(){


if (this.props.user.username != "Anonymous"){
  
this.props.getCartLen(this.props.user.username).then(res=>{
 
 this.props.setCartLen(res.data.len)

  
})
}


  }

  homeClick=(e)=>{



    const newValue = {location:this.props.get_current_address()}
    this.props.updateAjaxRoute(true)
this.props.setToHome(true);
     this.props.dailyDeals(newValue)

this.props.history.push('/')


  }



moremenu=(e)=>{

  this.setState({

    ...this.state,
    moremenu:!this.state.moremenu
  })
}

  desktop_nav=(e)=>  <Menu className="navigation desktop" mode="horizontal" >
       
       
                        <Menu.Item key={1} >
                       <img  src={logo192} className="logo animated pulse" alt="logo"  /> 
                       <a  onClick={this.homeClick} className="sitename animated bounce" style={{color: 'black','marginLeft':'6px'}} >beBO</a>
                        </Menu.Item>
                      <span className="top-nav-link hide-648" style={{'fontWeight':'bold'}}> 
                      <span style={{'marginRight':"13px"}}> Help & Contact </span>  
                      <span> Work with us </span></span>

                        <span className="to-right">

                      {this.props.user.authenticated ?
                        <>
                    
                <a onClick={e=>this.props.history.push("/dashboard")}   className="username">
                 <Avatar src={this.props.user.pic && BASE_IMG_URL+this.props.user.pic} style={{"width":'42px','height':'38px',
                'marginLeft':'15px'}} className="avatar">
                 <h2 style={{
                  'color':'white',
                  'fontSize':'26px'
                }}>  {this.props.user.username.slice(0,2)}</h2></Avatar>

                    
                  {this.props.user.username}</a> 
                  <a onClick={e=>this.props.history.push("/cart/"+this.props.user.username)} >
                    <ShoppingCartOutlined 
                      className="cart-icon" />
                    <Tag  style={{
                'borderRadius':"50%",
                "border":'0px solid',
                "position":"relative","left":"-37px",'top':'-10px',
                'backgroundColor':'green','color':'white'
                 }}>{this.props.cartDataLen}</Tag>

                </a>
                    <Button type="danger" className="log-in-out" onClick={e=>this.props.history.push("/logout")}>
                    
                    Log Out</Button>
                 
                        </>
                      :
                      <>
                            <a onClick={e=>this.props.history.push("/dashboard")} className="username">
                      <Avatar style={{"width":'35px','height':'35px',
                'marginLeft':'15px'}} icon={<UserOutlined></UserOutlined>} className="avatar"></Avatar>

                  {this.props.user.username} </a>
                      <ShoppingCartOutlined className="cart-icon"  onClick={e=>this.props.history.push("/login")} />
                     
                          <Button type="primary" className="log-in-out" onClick={e=>this.props.history.push("/login")
                          
                          }>
                          
                          Log In</Button>
                        
                      </>
                      }
                       
                      
                      </span>
                      
                        </Menu>



  mobile_nav=(e)=><div className="navigation mobile"> 

<div className="top-mobi">
<span onClick={this.homeClick} >
<img  src={logo192} className="logo animated pulse" alt="logo"  /> 

<a  className="sitename animated bounce" style={{color: 'black','marginLeft':'6px'}} >beBO</a>
   </span>


   <MenuOutlined onClick={this.moremenu} className='mobi-menu' />                    
</div>


{this.state.moremenu && <div className="bottom-mobi">
<hr/>
                      {this.props.user.authenticated ?
                        <>
                    
                <a onClick={e=>this.props.history.push("/dashboard")}   className="username">
                 <Avatar src={this.props.user.pic && BASE_IMG_URL+this.props.user.pic} style={{"width":'42px','height':'38px',
                'marginLeft':'15px'}} className="avatar">
                 <h2 style={{
                  'color':'white',
                  'fontSize':'26px'
                }}>  {this.props.user.username.slice(0,2)}</h2></Avatar>

                    
               <i className="mobile-user">   {this.props.user.username} </i></a> 
                  <a onClick={e=>this.props.history.push("/cart/"+this.props.user.username)} >
                    <ShoppingCartOutlined 
                      className="cart-icon" />
                    <Tag  style={{
                'borderRadius':"50%",
                "border":'0px solid',
                "position":"relative","left":"-37px",'top':'-10px',
                'backgroundColor':'green','color':'white'
                 }}>{this.props.cartDataLen}</Tag>

                </a>
                    <Button type="danger" className="log-in-out" onClick={e=>this.props.history.push("/logout")}>
                    
                    Log-Out</Button>
                 
                        </>
                      :
                      <>
                            <a onClick={e=>this.props.history.push("/dashboard")} className="username">
                      <Avatar style={{"width":'35px','height':'35px',
                'marginLeft':'15px'}} icon={<UserOutlined></UserOutlined>} className="avatar"></Avatar>

                 <i className="mobile-user"> {this.props.user.username} </i> </a>
                      <ShoppingCartOutlined className="cart-icon"  onClick={e=>this.props.history.push("/login")} />
                     
                          <Button type="primary" className="log-in-out" onClick={e=>this.props.history.push("/login")
                          
                          }>
                          
                          Log-In</Button>
                        
                      </>
                      }


</div>}

                    </div>


    render(){


const {user,onclick,history,cartDataLen } = this.props


// console.log("topnav "+Object.keys(user))
  
      return (
<>

{this.desktop_nav()}

{this.mobile_nav()}
</>

      )

    }
  }

  
 
  

  
  
  export default withRouter(connect(mapStateToProps,{setCartLen,getCartLen,setToHome,dailyDeals,updateAjaxRoute,get_current_address})(TopNav))

  TopNav.propTypes = {
      user: PropTypes.object.isRequired,
      onclick:PropTypes.func.isRequired,
      getCartLen:PropTypes.func.isRequired,
      setToHome:PropTypes.func.isRequired,
  }