
import React, { Component } from 'react';
import ReactDOM from 'react-dom';

import "antd/dist/antd.css"
import {Menu, Button,Row,Col,Card} from "antd";
import {FacebookOutlined,TwitterOutlined,LinkedinOutlined} from '@ant-design/icons';
import logo192 from "../../statics/logo192.png";
import "../../css/bottomnav.css"
import {connect} from 'react-redux'
import PropTypes from 'prop-types'
import {withRouter} from 'react-router-dom'
import {get_current_address} from "../../actions/location"






    const mapStateToProps= (state, props)=>({
    
        user:state.User
    })

    


  class BottomNav extends Component{

      constructor(props){
    super(props)
    this.state = {
    image:''
    }
  }


    render(){


const {user,history,get_current_address } = this.props
const address = get_current_address()

  
      return (
        <Card className="full-bottom">
<Row gutter={[12,12]} className="bottom-nav">

<Col className='buy-sell'>
<h2> Buy & Sell </h2>

<ul  style={{'color':'black'}}> 

<li>Registration </li>
<li> Buying & renting help</li>
<li> Start selling </li>
<li>Delivery </li>


</ul>
</Col>

<Col  className='stay-connect'>
<h2> Stay Connected </h2>
<ul style={{'color':'black'}}> 

<li><a href="https://www.facebook.com/beBO"> <FacebookOutlined></FacebookOutlined> Facebook </a> </li>
<li><a href="https://www.twitter.com/beBO"> <TwitterOutlined></TwitterOutlined> Twitter </a> </li>
<li> <a href="https://www.linkedin.com/beBO"><LinkedinOutlined></LinkedinOutlined>  Linkedin </a></li>



</ul>

</Col>


<Col  className='about'>
<h2> About beBO </h2>


<ul  style={{'color':'black'}}> 

<li>Company info </li>
<li> Advertise with us</li>
<li> Policies </li>



</ul>
</Col>

<Col  className='help'>
<h2> Help & Contact </h2>

<ul  style={{'color':'black'}}> 

<li>Contact us </li>

</ul>

<h2> beBo sites </h2>

<ul  style={{'color':'black'}}> 

<li>Lagos </li>

</ul>
</Col>
</Row>
</Card>
      )

    }
  }

  
 
  

  
  
  export default withRouter(connect(mapStateToProps,{get_current_address})(BottomNav))

  BottomNav.propTypes = {
      user: PropTypes.object.isRequired,
      get_current_address:PropTypes.func.isRequired
  }