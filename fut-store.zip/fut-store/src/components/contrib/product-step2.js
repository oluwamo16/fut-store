
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import "antd/dist/antd.css"
import {Input,Button,Row,Col,Form,Divider,Radio,Select,
InputNumber,Collapse} from "antd";
import {InfoCircleOutlined, UploadOutlined,PlusCircleOutlined,
  HomeOutlined,LoadingOutlined,FileImageOutlined,UpCircleOutlined,WhatsAppOutlined,
CarOutlined,PayCircleOutlined,CheckOutlined} from '@ant-design/icons';
import {useSelector} from 'react-redux'







const Step2=({handlechange, state})=>{

	const data= useSelector(state=>state.sHubInputs)


return <div className="upload-form animated zoomIn">

<h2 className='add-detl'> ADDITIONAL DETAILS </h2>
 
 <hr className="divider" />


<div className="grp-input">

<label className="item-aqt" htmlFor="acquire_type">Acquire Type </label>

<div>

<Radio.Group className="item-rad-aqt"  autoFocus 
onChange={e=>handlechange(e,'acquire_type')}  
name="acqure_type" defaultValue={data['acqure_type']? data['acqure_type']:"sale"}  buttonStyle="outline">

<Radio value="sale">Sale</Radio>
<Radio value="rent">Rental</Radio>
<Radio value="exchange">Exchange</Radio>

</Radio.Group> 
 
</div>

</div>



<div className="grp-input">
<label htmlFor="condtion" className="item-condtn">Condition </label> 
<div>

<Radio.Group className="item-rad-condtn" onChange={e=>handlechange(e,'condition')}  
name="condition" defaultValue={data['condition']? data['condition']:"new"} buttonStyle="outline">

<Radio value="new">New</Radio><Radio value="used">Used</Radio>

</Radio.Group>
</div>
</div>

<Row gutter={[12,12]} className="price-row">

<Col span={12}>

<div className="grp-input">

<label htmlFor="price" className="item-price">Price (*)</label>

<Input name="price" required allowClear prefix={"NGN(₦)"} type="number" value={data['price']} 
onChange={e=>handlechange(e,'price')}  autoComplete="true"  placeholder="10,000" autoFocus
/> 

</div>


</Col>


<Col span={8}>


<div className="grp-input">
<label htmlFor="negotiable" className="item-neg">Negotiable (*)</label>

<div>
 <Radio.Group className="item-rad-neg" onChange={e=>handlechange(e,'negotiable')} 
  name="negotiable" defaultValue={data['negotiable']? data['negotiable']:"no"} >

<Radio value="yes">Yes</Radio><Radio value="no">No</Radio>
</Radio.Group> 
</div>
</div>
</Col>

</Row>

<Row gutter={[12, 12]} >

<Col> 





<div className="grp-input" >
<Collapse accordion className="item-price-adv"  >
<Collapse.Panel key={1} header={"Price (Advanced)"}>

From: 
 <InputNumber defaultValue={data['from_price']? data['from_price']:0} onChange={e=>handlechange(e,'from_price')}  >

</InputNumber>  

To: <InputNumber  defaultValue={data['to_price']&& data['to_price']} onChange={e=>handlechange(e,'to_price')} >

</InputNumber>
</Collapse.Panel>


</Collapse>
</div>




</Col>

</Row>


<Row gutter={[12,12]}>

<Col span={7}>
{data['acquire_type']==="rent" ? 
<>

<div className="grp-input">
<label className="item-dur" htmlFor="price">Duration</label>

<div>


<Select className="item-sel-dur" onChange={(value)=>handlechange(value,"duration")} 
placeholder={data['duration']? data['duration']:"Duration"} defaultValue="weekly"
>
<Select.Option value="weekly">Weekly</Select.Option>
<Select.Option value="monthly">Monthly</Select.Option>
<Select.Option value="yearly">Yearly</Select.Option>

</Select> 



</div>
</div>
</>

:<></>
}



</Col>

<Col>

{data['acquire_type']==="rent" ? 

<div className="grp-input">

<label  className="item-dur-cnt" htmlFor="rent_dur_year">Duration Count</label>

<Input name="dur_count" minLength={1} maxLength={50} minLength={1} required allowClear  type="number"
onChange={e=>handlechange(e,'dur_count')}   placeholder="3" 
defaultValue={data['dur_count']? data['dur_count']:1}
/>

</div>
:<></> 
   }

   </Col>
   </Row>


<div className="grp-input">
<label className="item-instock" htmlFor="instock">Available inStock (*): </label> 

<InputNumber className="inp-instock" onChange={e=>handlechange(e,'instock')} 
 defaultValue={data['instock']? data['instock']:1}>

</InputNumber> 
 
</div>

<Row>
<Col span={24}>

<div className="grp-input">
<label htmlFor="descr" className="txta-lab">Descriptions (*) </label>
<div>
<textarea onChange={e=>handlechange(e,'description')}
 placeholder={data['description'] ? data['description']:"More details on property"}
 ></textarea>

</div>
</div>

</Col>
</Row>

<Row>
<Col span={24}>
{data['acquire_type']==="rent" ?


<div className="grp-input">
<label htmlFor="req" className="txta-lab">Requirements (Optional) </label>
<div>
<textarea onChange={e=>handlechange(e,'requirement')} 
 placeholder={data['requirement'] ? data['requirement']:"Enter requirement(s), if any"} >
</textarea> 
</div>


</div>

:<p></p>

}

</Col>
</Row>







<Row>
<Col span={24}>

{data['acquire_type']==="exchange" ?
<div className="grp-input">
<label htmlFor="req" className="txta-lab">Exchangable Items (Optional)</label> 
<div>
<textArea onChange={e=>handlechange(e,'exchange_items')} 
 placeholder={data['exchange_items'] ? data['exchange_items']:"Enter Exchangable item(s), if any"}>
</textArea>

</div>

</div>

:<p></p>

}

</Col>
</Row>


<Row>
<Col span={24}>

{data['condition']==="used" &&
<div className="grp-input">
<label htmlFor="req" className="txta-lab">Issues (Optional)</label> 
<div>
<textarea onChangee={e=>handlechange(e,'issue')} 
 placeholder={data['issue'] ? data['issue']:"Enter Item issue(s), if any"}>
</textarea>

</div>
</div>



}

</Col>
</Row>

</div>
}

export default Step2