

import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import "antd/dist/antd.css"
import {Modal, Alert} from "antd";
import {LoadingOutlined} from '@ant-design/icons';






export const bigload=(load,label="Loading...")=> <Modal closable={false} title={label} className='loading-modal' visible={load} centered>

{load && <LoadingOutlined spin className="load-func" />}

            </Modal> 
