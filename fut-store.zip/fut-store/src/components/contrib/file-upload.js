import React, {Component,useState,useEffect} from "react"
import ReactDOM from 'react-dom';
import "antd/dist/antd.css"
import {Button,Modal,Alert,Avatar,Carousel} from "antd";
import {LoadingOutlined,EditOutlined} from '@ant-design/icons';
import {connect,useSelector,useDispatch} from 'react-redux'
import PropTypes from 'prop-types'
import {withRouter} from 'react-router-dom'
// import {setFinishLoad,setImgUploadStat,setVerifyState} from '../../actions/storehub'
// import {bigload} from './beboloading'








const chunk_size=1024;


function GetFile({cur_file=0,send}){

	// const [file,setIndex] = useState(0)

	const file = useSelector(state=>state.shubImages)[cur_file]





const  loadData=()=>{

// const end = index + chunk_size;
 
//  if (index > file.size)
//       return ;

//   if (end > file.size)
//         end=file.size

send('image',file,'file')

}


return (

	<p>{loadData()} </p>


	)



}



export default withRouter(GetFile);














