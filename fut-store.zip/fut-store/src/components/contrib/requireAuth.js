
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import { Route,  Redirect} from 'react-router-dom'
import {connect} from 'react-redux'





export function PrivateRoute ({ component: Component, isAuthenticated, ...rest }) {
    return (
      <Route
        {...rest}
        render={(props) => isAuthenticated === true
          ? <Component {...props} />
          : <Redirect to={{ pathname: '/login', state: { from: props.location }}} />}
      />
    )
  }



  // for login/signup
export function PublicRoute ({component: Component, isAuthenticated, ...rest}) {
    return (
      <Route
        {...rest}
        render={(props) => isAuthenticated === false
          ? <Component {...props} />
          : <Redirect to='/' />}
      />
    )
  }


