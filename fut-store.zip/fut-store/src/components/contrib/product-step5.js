


import React, { Component,useState } from 'react';
import ReactDOM from 'react-dom';
import "antd/dist/antd.css"
import {Input,Button,Row,Col,Form,Divider,Radio,Select,
Upload,Modal, Alert, Steps, InputNumber,Collapse,Cascader,Typography} from "antd";
import {InfoCircleOutlined, UploadOutlined,PlusCircleOutlined,
  HomeOutlined,LoadingOutlined,FileImageOutlined,UpCircleOutlined,WhatsAppOutlined,
CarOutlined,PayCircleOutlined,CheckOutlined} from '@ant-design/icons';

import {useSelector} from 'react-redux'



const Step4=({handlechange, state})=>{

	const data= useSelector(state=>state.sHubInputs)


return <div className="delivery-upload animated zoomIn">
 <h2 className='add-detl'> PAYMENT OPTIONS(S) </h2>
 <hr className="divider" />

<div className="deli-input">


<label htmlFor="payment_type"  className="deli-label">Approved Payment Channel </label> <br/>


<Select  className="payment-type" onChange={(value)=>handlechange(value,"payment_type")} placeholder="Payment Type"
 defaultValue={data['payment_type']? data['payment_type']:"Bank Transfer, "} mode="multiple" 
>
<Select.Option value="Negotiable, ">Negotiable</Select.Option>
<Select.Option value="Cash, ">Cash</Select.Option>
<Select.Option value="Bank Transfer, ">Bank Transfer</Select.Option>
<Select.Option value="Online Transfer, ">Online Transfer</Select.Option>
<Select.Option value="Crypto, ">Crypto Currency</Select.Option>
<Select.Option value="Paypal, ">PayPal</Select.Option>
<Select.Option value="Other, ">Other</Select.Option>


</Select> 
</div>
</div>

}
export default Step4