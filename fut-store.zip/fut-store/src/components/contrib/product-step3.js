


import React, { Component,useState,useEffect} from 'react';

import {useDispatch,useSelector } from 'react-redux'
import ReactDOM from 'react-dom';
import "antd/dist/antd.css"
import {Form,Divider,Radio,Select,
Upload,Modal, Alert, Steps, InputNumber,Collapse,Cascader,Typography,Button,Row,Col} from "antd";
import {InfoCircleOutlined, UploadOutlined,PlusCircleOutlined,
  HomeOutlined,LoadingOutlined,FileImageOutlined,UpCircleOutlined} from '@ant-design/icons';

import {addHubImage,removeHubImage} from '../../actions/storehub'







function Step3({validate,formSend}){


const images = useSelector(state=>state.shubImages)

const dispatch = useDispatch()


function updateImage(file,FileList){


          // formSend('image_info',file)
          
            const reader = new FileReader()

            reader.readAsDataURL(file)


            reader.onload=e=>{

              file.thumbUrl=e.target.result

            	dispatch(addHubImage(file))

            	 // console.log(file)



            // let formdata = new FormData()

              // formdata.append('image', file)

              // this.formSend('image',formdata,'file')
              // reader.readAsArrayBuffer(file);
              
              }







            }


function removeImage(file){


dispatch(removeHubImage(file))

console.log(file)
// console.log('remove list length '+images.length)

return true

}






 return <div className="image_upload animated zoomIn">

 <h2 className='add-detl'> IMAGE(S) UPLOAD </h2>
 <hr className="divider" />

<Upload className='file-picker' onRemove={file=>removeImage(file)}  
defaultFileList={images && images}


beforeUpload={(file,FileList)=>{updateImage(file,FileList); 
  return false}} listType="picture-card" multiple showUploadList>
<Row>
<p><UploadOutlined style={{"fontSize":"30px", "color":"grey"}}>
    </UploadOutlined></p>
<Col>


</Col>
<Col>

  <p> Drag and drop image files to upload</p>
    <p style={{"color":"silver"}}> You can upload multiple images</p>
</Col>

<Col>
    <Button 
type="primary"> SELECT FILES</Button>

</Col>

</Row>



</Upload>


<p className="terms" style={{"color":"silver"}}> By uploading your product or item to beBO, you 
acknowledge that you agree to BebO shop's<Button type="link">Terms of  Service and 
Community Guidelines </Button> </p>



</div>
 


}



export default Step3