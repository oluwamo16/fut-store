import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import "antd/dist/antd.css"
import {Empty,List,Pagination,Card,Button,Avatar} from "antd";
import {LoadingOutlined,ArrowRightOutlined} from '@ant-design/icons';
import {connect} from 'react-redux'
import PropTypes from 'prop-types'
import {withRouter} from 'react-router-dom'

import SubmitProperty from "../submitproperty"
import "../../../css/filter.css"




// const mapDispatchToProps=dispatch =>({
//     onclick:f=>f
//     })
    
    const mapStateToProps= (state, props)=>({
    
      
        data:{}
       
    })

    


 class SellRent extends Component{
        
    
    constructor(props){
    super(props)



  
}





    
    render(){





      return (
<Card className="top-sell-rent"  >
<h2> 

<span className="big-sell-rent"> Sell, Rent or Exchange item on your shop </span> <SubmitProperty />
 </h2>
       

        </Card>

      )

    }
  }

  
 
  export default withRouter(connect(mapStateToProps,{})(SellRent))