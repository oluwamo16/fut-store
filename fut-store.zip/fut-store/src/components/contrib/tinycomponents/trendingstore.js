import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import "antd/dist/antd.css"
import {Empty,List,Pagination,Card,Button,Avatar} from "antd";
import {LoadingOutlined,ArrowRightOutlined} from '@ant-design/icons';
import {connect} from 'react-redux'
import PropTypes from 'prop-types'
import {withRouter} from 'react-router-dom'

import "../../../css/procat.css"
import {filterSearch} from "../../../actions/search"
import {updateAjaxRoute} from '../../../actions/ajaxroute'
import {handleFilterClick} from '../../../actions/filter'
import {get_current_address} from "../../../actions/location"





// const mapDispatchToProps=dispatch =>({
//     onclick:f=>f
//     })
    
    const mapStateToProps= (state, props)=>({
    
      
        maindata:state.MainData,
        routeStatus:state.ajaxRoute.status,
        searchFilterVal:state.searchData,
       
    })

    


 class Store extends Component{
        
    
   
    constructor(props){
    super(props)

    this.state = {
 data:[],
 routeStatus:false
      }

  
}






handleAll=(e)=>{
this.props.history.push('/signup')
}

    
    render(){

// const {history} = this.props;
const {data,routeStatus} = this.state;
const {page, pagesize} = this.state;

// const paginatedList = this.paginate(page,pagesize,data)





      return (
<Card className="create-store" >
<h2 style={{'fontWeight':'bolder','textAlign':'center'}}> 

Create your own shop for your business
<p></p><Button type="primary" style={{ 'border-radius': '0px'}}
onClick={this.handleAll}>Create now <ArrowRightOutlined> </ArrowRightOutlined> </Button></h2>
       

        </Card>

      )

    }
  }

  
 
  export default withRouter(connect(mapStateToProps,{updateAjaxRoute,get_current_address,handleFilterClick,filterSearch,updateAjaxRoute})(Store))