
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import "antd/dist/antd.css"
import {Empty,List,Pagination,Card,Button,Avatar} from "antd";
import {LoadingOutlined,ArrowRightOutlined} from '@ant-design/icons';
import {connect} from 'react-redux'
import PropTypes from 'prop-types'
import {withRouter} from 'react-router-dom'
import {getTopCompany} from "../../actions/agency"
import "../../css/procat.css"
import {filterSearch,dailyDeals} from "../../actions/search"
import {updateAjaxRoute} from '../../actions/ajaxroute'
import {handleFilterClick} from '../../actions/filter'
import {get_current_address} from "../../actions/location"
import {setToHome} from '../../actions/contrib'
import "../../css/animate-css/animate.min.css"
import {BASE_IMG_URL} from '../../settings'





// const mapDispatchToProps=dispatch =>({
//     onclick:f=>f
//     })
    
    const mapStateToProps= (state, props)=>({
    
      
        maindata:state.MainData,
        routeStatus:state.ajaxRoute.status,
        searchFilterVal:state.searchData,
       
    })

    


  class PopularShop extends Component{
        
    
    constructor(props){
    super(props)

    this.state = {
 data:[],
 routeStatus:false
      }

  
}



componentWillMount(){


    this.setState({
    ...this.state,
    routeStatus:true
  })

    this.props.getTopCompany().then(res=>{

// console.log('view---'+res.data.view)
  this.setState({
    ...this.state,
    data:res.data
  })

 
    this.setState({
    ...this.state,
    routeStatus:false,
     page:1,
        pagesize:15,
  })
})


   

}
paginate=(page=1, pagesize=10,data=[])=>{

  
    const splicelist = data.slice((page*pagesize)-pagesize, ((page*pagesize)));
  
    return splicelist;
       
 
  }

  pageChange=(page, pagesize)=>{

    this.setState({...this.state, page})
  }



change=(e)=>{

  this.setState({...this.state,click:e})

    
}

handleCatAll = (e)=>{

//   const newData = {...this.state,
// click:'',
// filtername:"Popular Shops"}

// handleFilterClick(this.props,newData,"popular-shop")
this.props.history.push('/popular-shop')


}



handleClick=(e)=>{

   const newData = {...this.state,
filtername:"Filter by shop: "+this.state.click}

handleFilterClick(this.props,newData,"store")
}

    
    render(){

const {history} = this.props;
const {data,routeStatus} = this.state;
const {page, pagesize} = this.state;

const paginatedList = this.paginate(page,pagesize,data)





      return (
<Card className="popular-category" >
<h2 style={{'fontWeight':'bolder'}}> Explore popular Shops 
 <Button className="see-all" type="primary" onClick={this.handleCatAll} 
 onMouseEnter={e=>this.change("Popular categories")}>See all 
 <ArrowRightOutlined> </ArrowRightOutlined> </Button></h2>
       

       {routeStatus ? <p className="small-loading animated zoomIn">Loading <LoadingOutlined spin></LoadingOutlined></p>
: data.length ?

<ul className='grp-cat'> 

{paginatedList.map((data,index)=>(<li 
  className="exp-cat animated fadeIn" onClick={e=>{
   // this.change(data.category);
   this.handleClick();
}} onMouseEnter={e=>this.change(data.agencyname)}>  
<p><Avatar   src={data.image && BASE_IMG_URL+data.image} >

<h1 style={{'fontSize':'30px',
'paddingTop':'15px','color':'white'}}
>{data.agencyname.slice(0,2)} </h1>
   </Avatar> </p>
<p className="cate-text">{data.agencyname == 'null' ?'null':data.agencyname}</p>

 </li>))}


 </ul> :
<Empty description="No Data Available">(0) item(s) found for shops</Empty>



}

        </Card>

      )

    }
  }

  
 
  

  
  
  export default withRouter(connect(mapStateToProps,{setToHome,updateAjaxRoute,dailyDeals,get_current_address,handleFilterClick,getTopCompany,filterSearch,updateAjaxRoute})(PopularShop))

  PopularShop.propTypes = {
 
           
      
      getCategory:PropTypes.func.isRequired,
      handleFilterClick:PropTypes.func.isRequired,
      get_current_address:PropTypes.func.isRequired,
     
     
      
  }