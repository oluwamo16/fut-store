
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import "antd/dist/antd.css"
import {Button,Tag} from "antd";
import {PlusOutlined} from '@ant-design/icons';
import {connect} from 'react-redux'
import PropTypes from 'prop-types'
import {withRouter} from 'react-router-dom'
import {uploadProperty} from "../../actions/contrib"





// const mapDispatchToProps=dispatch =>({
//     onclick:f=>f
//     })
    
    const mapStateToProps= (state, props)=>({
    
        user:state.User
    })

    


  class SubmitProperty extends Component{

    
    render(){



      return (
<span className= {"sell-rent-btn "+this.props.className} >
      <Button  onClick={e=>this.props.history.push("/submitProperty")} type="ghost" icon={
      <PlusOutlined /> }>Shop Hub</Button>
        </span>

      )

    }
  }

  
 
  

  
  
  export default withRouter(connect(mapStateToProps,{uploadProperty})(SubmitProperty))

  SubmitProperty.propTypes = {
      user: PropTypes.object.isRequired,
      uploadProperty:PropTypes.func.isRequired
  }