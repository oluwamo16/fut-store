
import React, { Component,useState } from 'react';
import ReactDOM from 'react-dom';
import "antd/dist/antd.css"
import {Input,Button,Row,Col,Form,Divider,
Upload,Modal, Alert, Steps,Typography} from "antd";
import {InfoCircleOutlined, UploadOutlined,PlusCircleOutlined,
  HomeOutlined,LoadingOutlined,FileImageOutlined,UpCircleOutlined,WhatsAppOutlined,
CarOutlined,PayCircleOutlined,CheckOutlined} from '@ant-design/icons';
import {connect,useDispatch} from 'react-redux'
import PropTypes from 'prop-types'
import {withRouter} from 'react-router-dom'
import {uploadProperty} from "../../actions/contrib"


import Home from "../navigation/home"
import "../../css/submitproperty.css"

import "../../css/animate-css/animate.min.css"
import VerifyHubItem from "./verify_hub_item"
import Step1 from './product-step1'
import Step2 from './product-step2'
import Step3 from './product-step3'
import Step4 from './product-step4'
import Step5 from './product-step5'
import {bigload} from './beboloading'
import getFile from './file-upload'
import {resetHubImage,setFinishLoad,setImgUploadStat,
  resetImgUploadStat,reset_inputs,setVerifyState,add_inputs,
} from '../../actions/storehub'





const mapDispatchToProps={uploadProperty,resetHubImage,
  setVerifyState,setFinishLoad,setImgUploadStat,resetImgUploadStat,add_inputs,reset_inputs}
    
  const mapStateToProps= (state, props)=>({
    
        user:state.User,
        verifyState:state.verifyState,
     
    })

    

    // let {currentInput,setCurrentInput} = useState(null);



  class SubmitPropertyForm extends Component{
        
    
    constructor(props){
              super(props)



    this.state={
                username:this.props.user.username,
                 acquire_type:"sale",
                 loading:false,
                 inputType:{

                 },
                 inputs:[],
                  images:[],
                  duration:'',
                  dur_count:"",
                  step:0,
           


              }
          }


componentDidMount(){
      document.title="beBO Store | Upload property"


      this.resetState()



      }

resetState=()=>{


              this.props.resetHubImage()
              this.props.resetImgUploadStat()
              this.props.reset_inputs()
                this.props.setVerifyState(false)   
              }




setLoadState=(e)=>{

                      this.setState({...this.state,loadState:e})
                    }

verifyupload=(e)=>{

                 this.props.setVerifyState(true)                
                     


                    }




// formSend=(type,data='',content="json")=>{


//                   const form ={type,data}


//                 if (content=="json"){
//                  this.state.socket.send(JSON.stringify(form))


//                 } else if (content=="file"){

//                 let rawData = new ArrayBuffer();

//                   this.state.socket.send(form)
//                 }



                       
//                         this.setState({...this.state,
//                             inputType:{type,status:false},
//                             loading:true
//                           })

//                 }






handlechange=(e,type)=>{
    
                        // console.log(type+'----'+e.target.value)



                      switch (type) {

                      case "exchange_items":{

                               this.props.add_inputs(type,e.target.value)
                                break;
                                }
                            

                        
                          case "category":{

                      this.props.add_inputs(type,Object.values(e)[1])


                                break;
                          }
                             


                      case "website":{

                        this.props.add_inputs(type,e.target.value)

                        break;
                        }

                      case "condition":{

                       
                         this.props.add_inputs(type,e.target.value)

                        break;
                        }


                      case "negotiable":{

                        this.props.add_inputs(type,e.target.value)
                        break;
                        }


                      case "from_price":{

                        this.props.add_inputs(type,e)
                        break;
                        }




                      case "to_price":{

                       this.props.add_inputs(type,e)

                        break;
                        }


                      case "instock":{

                       this.props.add_inputs(type,e)

                        break;
                        }

                          

                            case "title":{

                         this.props.add_inputs(type,e.target.value)

                             break;
                            }
                                
                               
                            case "delivery":{

                            this.props.add_inputs(type,e.target.value)
                        
                               break;
                              }
                               
                              case "delivery_comp":{

                               this.props.add_inputs(type,e)
                          
                                 break;
                                }
                                     

                              case "payment_type":{

                                this.props.add_inputs(type,e)
                          
                                  break;
                                }

                          case "location":{

                              this.props.add_inputs(type,e.target.value)
                                  break;
                              }
                                  
                                 

                            case "email":{

                              this.props.add_inputs(type,e.target.value)
                                  break;
                                }
                                    
                                  


                            case "tel":{

                             this.props.add_inputs(type,e.target.value)
                                break;
                                }
                                    

                               case "whatsapp_no":{

                             this.props.add_inputs(type,e.target.value)
                                break;
                                }
                                    


                            case "acquire_type":{

                                this.props.add_inputs(type,e.target.value)

                                  break;
                                }
                                    
                                  


                            case "price":{

                                this.props.add_inputs(type,e.target.value)

                                    break;
                                }
                                   
                            case "duration":{

                                 this.props.add_inputs(type,e)

                                  break;
                                }
                                    
                                  

                            case "dur_count":{

                           this.props.add_inputs(type,e.target.value)

                                break;
                                }


                            case "description":{
                      // console.log('description '+e.target.value)
                            this.props.add_inputs(type,e.target.value)

                                break;
                                }


                            case "issue":{
                      // console.log('description '+e.target.value)
                            this.props.add_inputs(type,e.target.value)

                                break;
                                }


                            case "requirement":{
                      // console.log('requirement '+e.target.value)
                               this.props.add_inputs(type,e.target.value)
                                break;
                                }
                            
                            default:
                                break;
                      }



                      }

// loadFunc=(status)=>  <Modal closable={false} title="Loading..." className='loading-modal' visible={status} centered>

              // {status && <LoadingOutlined spin className="load-func" />}

              //             </Modal> 


setCurrentStep=(step)=>{
              this.setState({...this.state,step})
            }




verifyUploadData = ()=> <VerifyHubItem 
         setCurrentStep={this.setCurrentStep} 
            />


validate=(type)=>{
 

                return this.state.inputType.type == type && this.state.loading ? <LoadingOutlined className="my-load" spin /> : 
                this.state.inputType.type == type && this.state.inputType.status == 1 ? <CheckOutlined className="my-load my-check" /> :
                 this.state.inputType.type == type &&  <p> {this.state.inputType.error} </p>

              }

steps=(stepStyle,step)=>{
            return <Steps direction="vertical"  current={step} className="sell-hub-step">


              <Steps.Step title={<p style={stepStyle(0)}> DETAILS </p>} icon={<InfoCircleOutlined style={stepStyle(0)} ></InfoCircleOutlined>} >

              </Steps.Step>
               <Steps.Step   title={<p style={stepStyle(1)}> MORE DETAILS </p>} icon={<InfoCircleOutlined style={stepStyle(1)}></InfoCircleOutlined>} >

              </Steps.Step>
              <Steps.Step   title={<p style={stepStyle(2)}> IMAGE(S) UPLOAD </p>} icon={<FileImageOutlined style={stepStyle(2)}></FileImageOutlined>} >

              </Steps.Step>

              <Steps.Step  title={<p style={stepStyle(3)}> DELIVERY </p>} icon={<CarOutlined style={stepStyle(3)}/>} >

              </Steps.Step>
              <Steps.Step  title={<p style={stepStyle(4)}> PAYMENT </p>} icon={<PayCircleOutlined style={stepStyle(4)}/>}>

            </Steps.Step>

            </Steps>

            }


stepMove=(value,step)=>{

                return <p>


              { value > 0 && 
                <Button type="ghost" className="step-next" 
                onClick={e=>this.setState({...this.state,step:value-1})}>Back</Button>
              }

              {value < 4 && 
              <Button className="step-next" type="primary" 
              onClick={e=>this.setState({...this.state,step:value+1})}>Next</Button>
              }
              </p>

               

              }


    
    render(){


const {verificationData,step,loadState} = this.state;
const {verifyState} = this.props



const stepStyle = (current)=>({
  'color': step===current? "#1890ff":"black",

})




      return (
            <>

            

 

 {bigload(loadState,"Processing...")}


{ verifyState && this.verifyUploadData()}






<div className="upload" >


<Home type='primary'></Home>
     <h1 className='sell-hub'>SHOP HUB </h1>
     <h2 className="sell-hub-det"> Upload Item on your shop</h2>




<div className="form-step animated bounceInLeft">
<Row >


<Col span={5} className='hub-col-steps'>

{this.steps(stepStyle,step)}



</Col>

<Col span={19}>


{step==0 &&

  <>
<Step1 handlechange={this.handlechange} state={this.state}  />
{this.stepMove(0,step)}
</>
 }

{step==1 &&

<>

<Step2 handlechange={this.handlechange} state={this.state}  />
{this.stepMove(1,step)}
</>
}



{step==2 &&

<>

<Step3  formSend={this.formSend} />
{this.stepMove(2,step)}
</>
}


{step==3 &&
  <>

<Step4 handlechange={this.handlechange} state={this.state}  />
{this.stepMove(3,step)}
</>

}


{step==4 &&


  <>

<Step5 handlechange={this.handlechange} state={this.state} />
{this.stepMove(4,step)}
</>

}







</Col>

</Row>



<p style={{'textAlign':'center'}} className="hub-process-btn">
 <Button className='verify-upload' onClick={e=>this.verifyupload()} 
 icon={<UpCircleOutlined></UpCircleOutlined>} 
 type="primary" size="large">Process Item</Button></p>



</div>


        </div>

       </>

      )

    }
  }

  
 
  

  
  
  export default withRouter(connect(mapStateToProps,mapDispatchToProps)(SubmitPropertyForm))

  SubmitPropertyForm.propTypes = {
      user: PropTypes.object.isRequired,
      uploadProperty:PropTypes.func.isRequired
  }
