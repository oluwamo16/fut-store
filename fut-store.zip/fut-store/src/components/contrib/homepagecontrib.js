
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import "antd/dist/antd.css"
import {Empty,List,Pagination,Card,Button,Avatar} from "antd";
import {LoadingOutlined,ArrowRightOutlined} from '@ant-design/icons';
import {connect} from 'react-redux'
import PropTypes from 'prop-types'
import {withRouter} from 'react-router-dom'
import {getCategory} from "../../actions/search"
import "../../css/procat.css"
import {filterSearch} from "../../actions/search"
import {updateAjaxRoute} from '../../actions/ajaxroute'
import {handleFilterClick} from '../../actions/filter'
import {get_current_address} from "../../actions/location"





// const mapDispatchToProps=dispatch =>({
//     onclick:f=>f
//     })
    
    const mapStateToProps= (state, props)=>({
    
      
        maindata:state.MainData,
        routeStatus:state.ajaxRoute.status,
        searchFilterVal:state.searchData,
       
    })

    


  export class FaceMask extends Component{
        
    
    constructor(props){
    super(props)

    this.state = {
 data:[],
 click:"Shoes for every style",
 routeStatus:false
      }

  
}






handleShoe=(e)=>{
  const newProps = {...this.props,
    updateAjaxRoute:updateAjaxRoute,
  get_current_address:get_current_address,
filterSearch:filterSearch}

handleFilterClick(newProps,this.state,"shoes")
}

    
    render(){

// const {history} = this.props;
const {data,routeStatus} = this.state;
const {page, pagesize} = this.state;

// const paginatedList = this.paginate(page,pagesize,data)





      return (
<Card className="shoe" >
<h2> 

Shoes of different brand for every style  
<p></p><Button type="ghost" 
onClick={this.handleShoe}>Shop now <ArrowRightOutlined> </ArrowRightOutlined> </Button></h2>
       

        </Card>

      )

    }
  }

  
 
  







  export class CreateStore extends Component{
        
    
    constructor(props){
    super(props)

    this.state = {
 data:[],
 routeStatus:false
      }

  
}






handleAll=(e)=>{
// console.log('category '+e)
    const {searchFilterVal, filterSearch,updateAjaxRoute } = this.props

updateAjaxRoute(true)

    const newValue = {...searchFilterVal,
        category:'all'}

// console.log('new-value== '+Object.keys(newValue))
            filterSearch(newValue)
}

    
    render(){

// const {history} = this.props;
const {data,routeStatus} = this.state;
const {page, pagesize} = this.state;

// const paginatedList = this.paginate(page,pagesize,data)





      return (
<Card className="create-store" >
<h2 style={{'fontWeight':'bolder','textAlign':'center'}}> 

Create your own special store
<p></p><Button type="primary" 
onClick={this.handleAll}>Shop now <ArrowRightOutlined> </ArrowRightOutlined> </Button></h2>
       

        </Card>

      )

    }
  }



  
  
  // export default withRouter(connect(mapStateToProps,{getCategory,filterSearch,updateAjaxRoute})(PopularCategory))

  // PopularCategory.propTypes = {
 
           
      
  //     getCategory:PropTypes.func.isRequired,
     
     
      
  // }