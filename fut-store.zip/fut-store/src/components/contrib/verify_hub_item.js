import React, {Component,useState,useEffect} from "react"
import ReactDOM from 'react-dom';
import "antd/dist/antd.css"
import {Button,Modal,Alert,Avatar,Carousel} from "antd";
import {LoadingOutlined,EditOutlined} from '@ant-design/icons';
import {connect,useSelector,useDispatch} from 'react-redux'
import PropTypes from 'prop-types'
import {withRouter,Redirect} from 'react-router-dom'
import {setFinishLoad,setImgUploadStat,setVerifyState,uploadStoreItem} from '../../actions/storehub'
import {bigload} from './beboloading'





const mapDispatchToProps={uploadStoreItem}

 const mapStateToProps= (state, props)=>({
    
        user:state.User,
        finishLoadState:state.finishLoad,
     
    })






function VerifyHubItem({history=null,setCurrentStep=f=>f,uploadStoreItem=f=>f,finishLoadState}){

// var [visible,setvisible] = useState(null)
var [verComplete,setVerComplete] = useState(false)
var [requireInp,setRequireInp] = useState(0)
var [loadStart,setLoadStart] = useState(false)
var [uploadDone,setuploadDone] = useState()




const dispatch = useDispatch()



const storeImages = useSelector(state=>state.shubImages)

// const finishLoadState = useSelector(state=>state.finishLoad)

const visible= useSelector(state=>state.verifyState)

const data= useSelector(state=>state.sHubInputs)

const username= useSelector(state=>state.User.username)

const imgUploadStat = useSelector(state=>state.imgUploadDone)



// console.log('images  '+Object.keys(storeImages).length)

// console.log('inputs+++ '+data.title)




// useEffect(e=>{

//         setvisible(view)
// })



const verifyDone=()=>{

          	history.push('/dashboard')
          }

const createForm=(form,key,label)=>{
              if (label=='images')
                    form.append(label ? label :key,storeImages[key])
              if(!label)
                  form.append(label ? label :key,data[key])

          }

const finishUpload=(e)=>{

            dispatch(setFinishLoad(true))
            // console.log('uploa  done',uploadDone)

            finishLoadState && setLoadStart(true)

            const form = new FormData()

            form.append('username',username)

            for (var x in data){

                    createForm(form,x)
               

            }

            for (var im in storeImages){

              createForm(form,im,'images')
                   // console.log(im+' - '+storeImages[im])
            }


        uploadStoreItem(form).then(res => {
          
           dispatch(setFinishLoad(false))

           dispatch(setVerifyState(false))
           setLoadStart(false)
           history.push("/upload_notification")
           

         
        })
  ;

            }
             



const formEdit=e=>{


           dispatch(setVerifyState(false))
        requireInp=[]

          e=='details' && setCurrentStep(0)
          e=='add_details' && setCurrentStep(1)
          e=='images' && setCurrentStep(2)
          e=='delivery' && setCurrentStep(3)
          e=='payment' && setCurrentStep(4)

                 
      }



const modifyImage=(images=[])=>{


                return  <span className="verify-all-images">

               {images.map((e,index)=>(
            
              <img key={index} className="hub-images" src={e.thumbUrl}></img>
                
            )
                )
            }
               </span>
        }


const validateData=(value,label,require=false,key)=>{
  // console.log('validate ---'+requireInp)



if(require){
          	if (value== null || value==undefined || value==""||value==" "){
              


            !(requireInp > 6)&& 
            setRequireInp(requireInp+1)  



          return <p className="validate-error">

          * {label} is required, edit
          </p>


          }

          }
          }


const modifyData= (key,require=false,label,el='p') =>{

   

        		return <> 

            <h4 className="label">{label ?label.toUpperCase() :key.toUpperCase()} </h4>

        { el==='p' ? 
        <p>{data[key] ? data[key] : <span className='no_data'>No {key} provided </span>} </p>
        :
        <pre>{data[key] ? data[key] : <span className='no_data'>
        No {label ? label: key} provided </span>} </pre>}		

       {validateData(data[key],label?label:key,require,key)}


        </> }




return  <>  
{bigload(loadStart,"Uploading images...")}


                <Modal className='verify-hub-modal' okType={requireInp >= 1 || Object.keys(storeImages).length < 1 ?
                  "ghost":"primary"}

                   okText={
                   requireInp >= 1 || Object.keys(storeImages).length < 1 ?<a>
                   Update required input to continue </a>
                   :<a onClick={e=>finishUpload()}>Complete Upload </a> } 

            cancelText={<a onClick={e=>{e.preventDefault();
                history.push('/');
                dispatch(setVerifyState(false));  }}  
                 type="danger">Cancel Upload </a>}



closable={false} visible={visible} title={
  <span className="ver-title"> Verify Upload Data, ({
    requireInp >= 1 || Object.keys(storeImages).length < 1 ? <i className="validate-error"> Update all required input and Re-process upload    </i>:

 <i className="validate-success"> All input validated  </i> }) 
    </span> } >

<h2> DETAILS
<Avatar className="item-edit-avatar" onClick={e=>formEdit('details')} >
<EditOutlined></EditOutlined></Avatar> </h2>
<hr className="divider" />

{modifyData('title',true)}
{modifyData('category',true)}
{modifyData('location',true)}
{modifyData('email',true)}
{modifyData('website',true)}
{modifyData('whatsapp_no',true,'Whatsapp Number')}


<h2> ADDITIONAL DETAILS 
<Avatar className="item-edit-avatar" onClick={e=>formEdit('add_details')} >
<EditOutlined></EditOutlined></Avatar> </h2>
<hr className="divider" />

{modifyData('acquire_type',false,"acquire type")}
{modifyData('condition')}


{modifyData('price',false) }
{modifyData('negotiable',false,'price negotiable')}

{data.from_price && modifyData('from_price',false,'Start Price') }
{data.to_price && modifyData('to_price',false,'End Price') }

{data.acquire_type==="rent" && modifyData('duration',false,'Rental duration') }
{data.acquire_type==="rent" && modifyData('dur_count',false,'duration Value') }

{modifyData('instock',false,"Available in stock")}

{modifyData('description',true,"item description(s)",'pre')}

{data.acquire_type==="rent" && modifyData('requirement',false,"item requirement(s)",'pre') }

{data.condition==="used" && modifyData('issue',false,"item issue(s)",'pre')}

{data.acquire_type==="exchange" && modifyData('exchange_item',false,"exchangable item(s)",'pre')}


<h2> UPLOAD IMAGE(S) 
<Avatar className="item-edit-avatar" onClick={e=>formEdit('images')} >
<EditOutlined></EditOutlined></Avatar></h2>
<hr className="divider" />

{Object.keys(storeImages).length >0 ? modifyImage(storeImages): 
	<p className='validate-error'>No Images uploaded, (required at least a picture) </p>}

<h2> DELIVERY OPTIONS
 <Avatar className="item-edit-avatar" onClick={e=>formEdit('delivery')} >
<EditOutlined></EditOutlined></Avatar> </h2>
<hr className="divider" />

{modifyData('delivery',false,"delivery option")}

{modifyData('delivery_comp',false,"delivery channel")}




<h2> PAYMENT OPTIONS 
<Avatar className="item-edit-avatar" onClick={e=>formEdit('payment')} >
<EditOutlined></EditOutlined></Avatar></h2>
<hr className="divider" />

{modifyData('payment_type',false,"Approved Payment Channel")}

            </Modal> </>

}






  export default withRouter(connect(mapStateToProps,mapDispatchToProps)(VerifyHubItem))
