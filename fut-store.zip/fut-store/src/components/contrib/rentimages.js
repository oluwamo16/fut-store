import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import "antd/dist/antd.css"
import {Carousel,Divider,Button} from 'antd';
import PropTypes from 'prop-types'
import {BASE_IMG_URL} from '../../settings'







const RentImg=({images=[]})=>{

    

    return (
    
        <>
    
        <Carousel style={{'height':'400px'}}  className="carousel-img" autoplay autoplaySpeed={4700} effect="fade" dotPosition="bottom">
        {images.map((e,index)=>(
    
            <img  key={index} style={{'max-height':'590px'}} className="data-image" src={BASE_IMG_URL+e.images}></img>
            
        )
            )
        }
       </Carousel>

       <Button className="images-length" type="danger">({images.length}) images</Button>
<Divider></Divider>
       <ul className="all-images">
       {images.map((e,index)=>(
    
        <li><img key={index} className="data-images" src={BASE_IMG_URL+e.images}></img></li>
        
    )
        )
    }
       </ul>
    
    
        </>
    )
    
    }


export default RentImg

RentImg.propTypes = {
 
        images:PropTypes.array,     
      
    }