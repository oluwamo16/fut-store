
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import "antd/dist/antd.css"
import {Tag,Statistic,Button,Rate,Typography,Avatar,Empty,Card} from "antd";
import {HeatMapOutlined} from '@ant-design/icons';
import {connect} from 'react-redux'
import PropTypes from 'prop-types'
import {withRouter} from 'react-router-dom'
import {toView} from "../../actions/rent_to_view"
import {setToHome} from '../../actions/contrib'
import "../../css/animate-css/animate.min.css"
import {BASE_IMG_URL} from '../../settings'
import {handleFilterClick} from '../../actions/filter'
import {slice} from 'lodash'

import {updateAjaxRoute} from '../../actions/ajaxroute'
import {filterSearch,dailyDeals} from "../../actions/search"
import {get_current_address} from "../../actions/location"
import {shuffle} from 'lodash'



const mapStateToProps= (state, props)=>({
    
    filterTag:state.filterData.data,
    filterType:state.filterData.filterType,

})




  class Shops extends Component{
        
    
    constructor(props){
    super(props)

    this.state = {
   page:1,
        pagesize:15,
          bgStyles:[
'golden','red','green','silver','blue']
      }

  
}

paginate=(page=1, pagesize=10,data=[])=>{

  
    const splicelist = data.slice((page*pagesize)-pagesize, ((page*pagesize)));
  
    return splicelist;
       
 
  }

  pageChange=(page, pagesize)=>{

    this.setState({...this.state, page})
  }


change=(e)=>{

  this.setState({...this.state,click:e})

    
}




handleClick=(e)=>{

   const newData = {...this.state,
    click:e,
filtername:"Filter by shop: "+e}

handleFilterClick(this.props,newData,"store")
}



    
    render(){


const {data} = this.props


const {history} = this.props;


      return (


<>
       

       { Object.keys(data).length >0 ?


<li 
  className="exp-cat animated fadeIn" onClick={e=>{
   // this.change(data.category);
   this.handleClick(data.agencyname);
}} >  
<p><Avatar style={{
  'backgroundColor':shuffle(this.state.bgStyles)[1]}}   src={data.image && BASE_IMG_URL+data.image} >

<h1 style={{'fontSize':'30px',
'paddingTop':'15px','color':'white'}}
>{data.agencyname.slice(0,2)} </h1>
   </Avatar> </p>
<p className="cate-text">{data.agencyname == 'null' ?'null':data.agencyname}</p>

 </li>




:
<Empty description="No Data Available">(0) item(s) found for shops</Empty>



}


</>
      )

    }
  }

  
 
  

  
  
  export default withRouter(connect(mapStateToProps,{updateAjaxRoute,filterSearch,dailyDeals,get_current_address,toView,setToHome,handleFilterClick})(Shops))

Shops.propTypes = {
 
      data:PropTypes.array.isRequired,     
    //   searchFilterVal:PropTypes.object.isRequired,
      city:PropTypes.func.isRequired,
    //   updateAjaxRoute:PropTypes.func.isRequired,
      
  }