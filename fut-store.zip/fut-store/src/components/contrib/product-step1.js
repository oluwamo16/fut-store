
import React, { Component,useState } from 'react';
import ReactDOM from 'react-dom';
import "antd/dist/antd.css"
import {Input,Button,Row,Col,Form,Divider,Radio,Select,
Upload,Modal, Alert, Steps, InputNumber,Collapse,Cascader,Typography} from "antd";
import {InfoCircleOutlined, UploadOutlined,PlusCircleOutlined,
  HomeOutlined,LoadingOutlined,FileImageOutlined,UpCircleOutlined,WhatsAppOutlined,
CarOutlined,PayCircleOutlined,CheckOutlined} from '@ant-design/icons';
import Options from "./category_option"
import {connect,useSelector,useDispatch} from 'react-redux'



const Step1=({handlechange})=>{

	const data= useSelector(state=>state.sHubInputs)
	// console.log(data[])


 return <Form className="upload-form animated zoomIn">
 <h2 className='add-detl'> DETAILS </h2>
 <hr className="divider" />


<div className="grp-input">
<label className="item-title" htmlFor="title">Item Title (*) </label>
<div>
<Input name="title" required allowClear
onChange={e=>handlechange(e,'title')} autoFocus  autoComplete="true" value={data['title']}  placeholder="eg. 3 Bedroom Flats, New Gks Generator(Black)"
/>


</div>

</div>

<div className="grp-input">
<label className="item-category" htmlFor="cate">Category (*) </label>

<p>
<Cascader
displayRender={(e,f)=>e } expandTrigger="hover" 
placeholder={ data['category'] ?data['category']:"Select Category"} options={Options} onChange={e=>handlechange(e,'category')} />

</p>
</div>




<div className="grp-input">

<label className="item-addr" htmlFor="locn">Item Address (*) </label>
<Input name="locn" required allowClear  value={data['location']}
onChange={e=>handlechange(e,'location')}  autoComplete="true"  placeholder="eg. Ikeja, Lagos State"
/>

</div>



<div className="grp-input">
<Row gutter={[12, 12]} >
 <Col>
 
 
<label className="item-email" htmlFor="email">Shop E-mail (*)</label>
<Input name="email" required allowClear prefix={"@"} type="email"  value={data['email']}
onChange={e=>handlechange(e,'email')}   autoComplete="true"  placeholder="eg. beBO@gks.co"
/> 
</Col>

 <Col>  
<label  htmlFor="tel" className="item-tel">Shop Phone-No (*)</label>
<Input name="tel" required allowClear prefix={"+234"} type="tel"  value={data['tel']}
onChange={e=>handlechange(e,'tel')}  autoComplete="true"  placeholder="i.e. 8061344475, 08061344475"
/> 


</Col>

</Row>

</div>



<div className="grp-input">

<label htmlFor="tel" className="item-site">Shop Website (Optional) </label>
<Input name="website"  value={data['website']} required allowClear prefix={"http://"} type="text"
 onChange={e=>handlechange(e,'website')}  autoComplete="true"  placeholder="i.e. www.alaba21store.com"
/> 
</div>



<div className="grp-input">

<label htmlFor="tel" className="item-whapp">Whatsapp Contact (Optional) </label>
<Input name="whatsapp_no" required allowClear prefix={<WhatsAppOutlined />} type="text"
onChange={e=>handlechange(e,'whatsapp_no')}  value={data['whatsapp_no']}  autoComplete="true"  placeholder="Enter your whatsapp contact"
/> 
</div>





</Form>

}


export default Step1