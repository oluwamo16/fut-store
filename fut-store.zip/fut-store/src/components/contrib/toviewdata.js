
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import "antd/dist/antd.css"
import {Avatar, Button,Divider,Table, Statistic,Row,Col,
  Tabs,Breadcrumb,Empty,Pagination,Rate,Comment,Input,Form,Tag,Typography} from 'antd';
import {HomeOutlined,UserOutlined,LoadingOutlined,LikeOutlined,
  ArrowRightOutlined,UploadOutlined,CheckOutlined,PhoneOutlined,WhatsAppOutlined} from '@ant-design/icons';
import {connect} from 'react-redux'
import PropTypes from 'prop-types'
import {withRouter} from 'react-router-dom'

import {addView,setToViewStatus,toView,addLike,youMayLike,addRate,addReview} from "../../actions/rent_to_view"
import {addItemToCart} from "../../actions/cart"
import RentImg from '../contrib/rentimages'
import Review from '../contrib/reviews'
import "../../css/viewrent.css";

import Home from "../navigation/home"
import SubmitProperty from "../contrib/submitproperty"
import {updateAjaxRoute} from '../../actions/ajaxroute'
import {setCartLen} from '../../actions/cart'
import "../../css/toviewdata.css"
import {BASE_IMG_URL} from '../../settings'







const mapStateToProps= (state, props)=>({
    
	routeStatus:state.ajaxRoute.status,
  to_view:state.toView,
   user:state.User
   
})





  class ToViewData extends Component{
        
    
    constructor(props){
    super(props)
    this.state={
      data:{},
      views:1,
      page:1,
      pagesize:8,
      rates:0,
      cartLoad:false
    }

  
}

componentWillMount(){
// console.log('to view=> '+Object.keys(this.state.data))
this.props.updateAjaxRoute(true)

this.props.toView(this.props.match.params.id).then(res=>{


this.props.setToViewStatus(res.data)

this.props.updateAjaxRoute(false)
  
})

 


}

componentDidMount(){


document.title = this.props.to_view.data.title;

  this.setState({
    ...this.state,
    rates:this.props.to_view.data.submit_user.rate

  })


this.props.addView(this.props.match.params.id).then(res=>{

// console.log('view---'+res.data.view)
  this.setState({
    ...this.state,
    views:res.data.view

  })


})

const store = this.props.to_view.data.submit_user.agencyname
this.props.youMayLike(store,this.props.match.params.id).then(res=>{

// console.log('view---'+res.data.view)
  this.setState({
    ...this.state,
    maylike:res.data?res.data:null
  })


})




}


submitReview=(e,username)=>{


this.props.addReview(this.props.match.params.id,this.state.review,username).then(res=>{

// console.log('rate---'+res.data.rate)
  this.setState({
    ...this.state,
    reviews:res.data.reviews
  })


})



}


  change=(page, pagesize)=>{

    this.setState({...this.state, page})
  }

handleReview=(e)=>{


// console.log('review---'+e.target.value)
  this.setState({
    ...this.state,
    review:e.target.value
  })


}

handleLike=()=>{



this.props.addLike(this.props.match.params.id).then(res=>{

// console.log('view---'+res.data.view)
  this.setState({
    ...this.state,
    likes:res.data.like
  })


})



}


handleRate=(value)=>{



this.props.addRate(this.props.match.params.id,value).then(res=>{

// console.log('rate---'+res.data.rate)
  this.setState({
    ...this.state,
    rates:res.data.rate
  })


})



}

addToCart=(username)=>{
    this.setState({
    ...this.state,
    cartLoad:!this.state.cartLoad,
    viewContact:false
  })

this.props.addItemToCart(this.props.match.params.id,username).then(res=>{

// console.log('progress---'+res.data)

this.props.setCartLen(res.data.rents.length)


   this.setState({
    ...this.state,
    cartLoad:!this.state.cartLoad,
    cartAdd:true
  })

})



}

getDuration=(duration)=>{

switch(duration){

  case("Weekly"):{

    return "Week(s)"
    break;
  }

  case("Monthly"):{

    return "Month(s)"
    break;
  }

  case("Yearly"):{

    return "Year(s)"
    break;
  }
}

}

paginate=(page=1, pagesize=10,data=[])=>{

  
    const splicelist = data.slice((page*pagesize)-pagesize, ((page*pagesize)));
  
    return splicelist;
       
 
  }

viewContact=(e)=>{

e.persist()
  this.setState({...this.state,
    viewContact:!this.state.viewContact})
}

    
    render(){

      const {history,routeStatus,user} = this.props
const {data} = this.props.to_view;

const {page, pagesize,maylike,cartLoad,cartAdd} = this.state;

const paginatedList = maylike
// const paginatedList = this.paginate(page,pagesize,maylike)

const paginatedReview = this.paginate(page,pagesize,this.state.reviews ? this.state.reviews:data && data.reviews)



// console.log("state data: ", Object.values(data))

       const dataSource = data && Object.keys(data).length ? [
        {
          key: '1',
          name: 'Category',
          value: data.category,
      
        },
        {
          key: '2',
          name: 'Location',
          value: data.address,
      
        },
        {
            key: '3',
            name: 'Acquire Type',
            value: data.acquire_type,
          },
          {
            key: '4',
            name: 'Duration',
            value: data.duration ? data.duration:"None Available",
          },
          ,
          {
            key: '5',
            name: 'Price',
            value:data.from_price != 0 ? <>
<Statistic  prefix={"₦"} value={data.from_price}></Statistic>  <span>To </span>
<Statistic prefix={"₦"} value={data.to_price}></Statistic> 

</>:
<Statistic prefix={"₦"} value={data.price}></Statistic> 
          }
      ] : [];
      
      const columns = [
        {
            title: '',
            dataIndex: 'name',
            key: 'name',
          },
        {
          title: '',
          dataIndex: 'value',
          key: 'value',
        },
   
      ];


      const contactDataSource = data && Object.keys(data).length ? [
        {
          key: '1',
          name: 'Store',
          value: data.submit_user.user.username,
      
        }, 
        {
            key: '2',
            name: 'Seller Number',
            value: <span> {data.phone_no} <PhoneOutlined /> </span>,
          },

          {
            key: '3',
            name: 'Seller whatsApp No',
            value: <span>  {data.whatsapp_no} <WhatsAppOutlined /> </span>,
          },

                    
          {
            key: '4',
            name: 'Seller E-mail',
            value: data.email,
          },
          {
            key: '5',
            name: 'Store Number',
            value: <span> {data.submit_user.phone_no} <PhoneOutlined /> </span>,
          },
      ]:[];
      
      const contactColumns = [
        {
       
            dataIndex: 'name',
            key: 'name',
          },
        {
          
          dataIndex: 'value',
          key: 'value',
        },
   
      ];


      const iconStyle = {
        "fontSize":"23px",
            "marginLeft":"15px"
      }




      return (
<>

<div className="top-nav">

{routeStatus ?  
<p></p>
:<p>
<Breadcrumb >
<Breadcrumb.Item  onClick={e=>{
this.props.history.push('/')} }><HomeOutlined></HomeOutlined> {data.submit_user.agencyname ? data.submit_user.agencyname:"No Store"} </Breadcrumb.Item>
      <Breadcrumb.Item >{data.category} </Breadcrumb.Item>
    
      </Breadcrumb> </p>
}





{routeStatus ? <p>Loading <LoadingOutlined spin></LoadingOutlined></p>:







<div className="data-div">
<h3 className="rent-name">{data.submit_user.agencyname ? data.submit_user.agencyname:"No Shop"} 


 <SubmitProperty className="submit-prop"></SubmitProperty>

</h3>
<p><Rate defaultValue={this.state.rates} value={data.submit_user.rate} allowClear={false} disabled> </Rate> ({data.submit_user.rate_count}) </p>
<p className="addr">{data.address}</p>
<p className='data-info'>
<span className="views">({this.state.views ? this.state.views: data.views}) Views, </span> 
<span> <LikeOutlined></LikeOutlined> ({this.state.likes ? this.state.likes:data.likes}) Likes,</span>
<span> Upload on: ({data.created})</span>  </p>
   




 <Row gutter={[12,12]}>
<Col span={14} className='item-info'>

<RentImg images={data.images}></RentImg>





<Divider className="divide-hide"></Divider>

<div >


<Tabs type="card" tabPosition="top" className="info-tab"  defaultActiveKey="description" >

{data.description && 
<Tabs.TabPane key="description" tab="DESCRIPTION(S)" >

{data.description ? 
  <pre>

{data.description}
</pre>
:

<Empty description="No description for item">

</Empty>
}



  </Tabs.TabPane>
}


{data.requirement &&
<Tabs.TabPane key="requirement" tab="REQUIREMENT(S)" >

{data.requirement ? 
  

<pre>

{data.requirement}
</pre>

:

<Empty description="No Requirement(s) available for item">

</Empty>
}

</Tabs.TabPane>

}

{data.issue &&

<Tabs.TabPane key="issue" tab="ISSUE(S)" >

{data.issue ? 
  

<pre>

{data.issue}
</pre>

:

<Empty description="No Issue(s) available for item">

</Empty>
}

   
</Tabs.TabPane>

}

{data.exchange_item &&

<Tabs.TabPane key="issue" tab="EXCHANGEABLE ITEM(S)" >

{data.exchange_item ? 
  

<pre>

{data.exchange_item}
</pre>

:

<Empty description="No exchange item(s) available for item">

</Empty>
}

   
</Tabs.TabPane>

}


</Tabs>



</div>










</Col>


<Col span={10} className="item-contact">

    
<div>
<h1>{data.title}</h1>
<p style={{'fontStyle':'italic'}} >Exclusive Seller on beBo: <span style={{'fontWeight':'bold',
'fontStyle':'normal','color':'red'}}>{data.submit_user.agencyname}</span></p>
<p className='instock'> {data.instock} item(s) in Stock</p>
<p> 

  
<Avatar src={BASE_IMG_URL+data.submit_user.image} style={{"width":'35px',
'height':'35px'}} className="avatar"><h2 style={{
  'color':'white'
}}>{data.submit_user.user.username[0]}</h2></Avatar> <Rate onChange={e=>this.handleRate(e)}></Rate><Button type="link" >


Rate this store
    </Button>

</p>
<p>Seller: <span style={{'color':'red'}}>{data.submit_user.agencyname} </span></p>
  <Button className="likeitem" type="link" onClick={e=>this.handleLike()} >
  <Avatar className="like-avatar" style={{'marginRight':'8px'}}><LikeOutlined></LikeOutlined></Avatar>
    Like this Item  </Button>


<div className="info-table">

  
<p>
 <span className='data-detl'> Acquire: </span>
  <span className='data-val'> {data.acquire_type.toUpperCase()} </span> 
</p>



{ data.condition && 
<p>
 <span className='data-detl'>Condition:</span> 
  <span className='data-val'>{data.condition}</span> 
</p>

}

<p>
  <span className='data-detl'> Item Location:</span>
   <span className='data-val'> {data.address} </span>
</p>





<p>
  <span className='data-detl'> Price: </span>
   <span className='data-val'>
{data.from_price != 0 ? <>
<Statistic  prefix={"₦"} value={data.from_price}></Statistic>  <span style={{
  'fontWeight':'bolder'
}}> - </span>
<Statistic prefix={"₦"} value={data.to_price}></Statistic> 

</>:
<Statistic prefix={"₦"} value={data.price}></Statistic> }
</span>
</p>





<p>
  <span className='data-detl'>Negotiable:</span> 
  <span className='data-val'> {data.negotiable}  </span>
</p>


{data.acquire_type=='rent'?
<>
{data.duration ? 

<p>
     <span className='data-detl'> Duration: </span>
      <span className='data-val'> Every {data.dur_count} {
     this.getDuration(data.duration)} </span>

    
     </p>: <></>
}

</>

:<></>


}






  
<p>
 <span className='data-detl'>Delivery:  </span>

   <span className='data-val'>   {data.with_delivery? " Provided by seller":" Not Provided"} </span>
</p>


{data.delivery_company? 
<p>
  <span className='data-detl'>Delivery Company:</span>  
  <span className='data-val'>{data.delivery_company}  </span>
</p> :<></>

}

<p>
   <span className='data-detl'> Payments Type: </span>
      <span className='data-val'>{data.payment_type} </span>
</p>




{user.authenticated ?

<Button className="cart-to-site add2cart" style={{'min-width':"200px"}} type="ghost"
 onClick={e=>this.addToCart(user.username)}>Add to cart
{ cartLoad ?
<LoadingOutlined spin />:<></>
 }

 {cartAdd ?
<Tag color="green"   style={{
'borderRadius':"50%",'marginLeft':'15px',
"border":'0px solid'
 }}> <CheckOutlined /> </Tag>:<></>
 }

 </Button>

 :<Button className="cart-to-site add2cart"  onClick={e=>this.props.history.push('/login')}>Login to Add to cart </Button>

}

 {data.website ?

<Button className="cart-to-site"style={{'min-width':"200px"}}  
type="primary" onClick={e=>document.location='http://'+data.website}> Visit Store ({data.website})</Button>
:
<> </>}




</div>
</div>

 <div style={{'textAlign':'center'}} >
<Button type="primary" className="agent-contact" onClick={this.viewContact}>SHOW SELLER CONTACT </Button>

</div>

{

  this.state.viewContact &&
    <Table className="viewContact"  sortDirections={["ascend","descend"]} tableLayout="auto" 
  
    dataSource={contactDataSource} columns={contactColumns} />
}
  


</Col>

</Row>

<div className="review-package">
<h2 className="store-review">{this.state.reviews ?this.state.reviews.length :data.reviews.length} store reviews  </h2>
{paginatedReview?
  <>
<Review content={paginatedReview} />



  <Pagination pageSize={pagesize}  
showTotal={(e,i)=>("Total "+e + " item(s)")} onChange={(page,pagesize)=>{
this.change(page, pagesize)
}} total={Object.keys(this.state.reviews ?this.state.reviews:data.reviews).length} responsive={true} />


</> :
<Empty description="No available review(s)">

</Empty>
 }








{user.authenticated ?
  <Form  style={{"marginTop":'10px'}}>
 <Avatar src={BASE_IMG_URL+user.pic} style={{"width":'35px','height':'35px'}} className="avatar"><h2 style={{
  'color':'white'
}}>{user.username[0]}</h2></Avatar> <Input name="review" required allowClear 
onChange={e=>this.handleReview(e)}  
autoComplete="true"  placeholder="Review on item" 
style={{'width':"50%"}}
/>


<Button type="primary" style={{"marginLeft":'5px','height':'35px',
'top':'2px'}}   onClick={e=>this.submitReview(e,user.username)}> <ArrowRightOutlined>
    </ArrowRightOutlined> </Button>

</Form>
: <Button style={{'marginTop':'15px',
'width':'60%'}} type="primary" onClick={e=>history.push('/login')}>Login to Post Review</Button>
 }

</div>

<Tabs tabPosition="top"  defaultActiveKey="maylike" >


<Tabs.TabPane key="maylike" tab={"More from "+data.submit_user.agencyname} >



<ul className='cart-reco'>

{this.state.maylike ?

  paginatedList.map((data,index)=>(   <a
   onClick={e=>{
      // this.props.toView(value);

        document.location = '/property/views/'+data.id;    }
  }><li key={index}>

<p><img key={index} className="data-images"
 src={BASE_IMG_URL+data.images[0].images}></img> </p>

 <Typography.Text ellipsis className='title'>{data.title} </Typography.Text>
<p className='price'>{data.from_price != 0 ? <>
<Statistic  prefix={"₦"} value={data.from_price}></Statistic>  <span className='space'> -  </span>
<Statistic prefix={"₦"} value={data.to_price}></Statistic> 

</>:
<Statistic prefix={"₦"} value={data.price}></Statistic> } </p>
<p className="new" style={{'color':'red'}}>Popular </p>


  </li></a>)
  )



: <Empty description="No available item(s) you may like">

</Empty>}



</ul>


</Tabs.TabPane>

</Tabs>






    
    </div>

}


</div>




</>
      )

    }
  }

  
 
  

  
  
  export default withRouter(connect(mapStateToProps,{setCartLen,addItemToCart,addRate,addReview,youMayLike,toView,addView,addLike,updateAjaxRoute,setToViewStatus})(ToViewData))

ToViewData.propTypes = {
 
      routeStatus:PropTypes.bool,   
      to_view:PropTypes.object  
    
  }