
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import "antd/dist/antd.css"
import {Tag,Statistic,Button,Rate,Typography} from "antd";
import {HeatMapOutlined} from '@ant-design/icons';
import {connect} from 'react-redux'
import PropTypes from 'prop-types'
import {withRouter} from 'react-router-dom'
import {toView} from "../../actions/rent_to_view"
import {setToHome} from '../../actions/contrib'
import "../../css/animate-css/animate.min.css"
import {BASE_IMG_URL} from '../../settings'



const mapStateToProps= (state, props)=>({
    
    filterTag:state.filterData.data,
    filterType:state.filterData.filterType,

})




  class ListViewRent extends Component{
        
    
    constructor(props){
    super(props)

  
}



handleClick=(id)=>{

// this.props.setToHome(false)
this.props.history.push("/property/views/"+id)




}
    
    render(){


const {data,key} = this.props
      return (
<li className="listviewdata animated fadeIn" onClick={e=>this.handleClick(data.id)} key={key} >

<Tag className="acquire-tag"   style={{
'borderRadius':"0px",'border':'0px solid'
 }} >{data.acquire_type}</Tag>

<p className='item-img'>
<img alt="first image" src={BASE_IMG_URL+data.images[0].images} /> </p>
 
 <Typography.Text ellipsis>{data.submit_user.agencyname} </Typography.Text>

 <br/>

 <span style={{'color':'lightBlue'}}><Rate className='rate'  value={data.submit_user.rate} allowClear={false} disabled> </Rate> ({data.submit_user.rate_count}) </span> <br/>
 <Typography.Title ellipsis style={{'color':'black',
 "fontSize":"16px"}}>{data.title}</Typography.Title>


<span className="price">
 {data.from_price != 0 ? <>
<Statistic  prefix={"₦"} value={data.from_price}></Statistic>  <span>- </span>
<Statistic prefix={"₦"} value={data.to_price}></Statistic> 

</>:
<Statistic prefix={"₦"} value={data.price}></Statistic> }
</span>
<br/>
    <Typography.Text style={{'color':'red'}}> {data.instock} item(s) in Stock</Typography.Text> <br/>
      <Typography.Text> Check It Now </Typography.Text>
        </li>

      )

    }
  }

  
 
  

  
  
  export default withRouter(connect(mapStateToProps,{toView,setToHome})(ListViewRent))

ListViewRent.propTypes = {
 
      data:PropTypes.array.isRequired,     
    //   searchFilterVal:PropTypes.object.isRequired,
      city:PropTypes.func.isRequired,
    //   updateAjaxRoute:PropTypes.func.isRequired,
      
  }