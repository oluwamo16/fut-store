
<p className="cart-top-det"> <span className="your-cart"> YOUR CART </span>

<Button className="cont-shop" onClick={e=>this.props.history.push('/')}>Continue Shopping </Button>
 </p>



{routeStatus ? <p className="down-div">Loading <LoadingOutlined spin></LoadingOutlined></p>:







<div className="down-div">

{selectItem ? 

  <Modal closable={false}  visible={this.state.contact} centered title={<h2>Contact information for ({selectItem.title})</h2>}  okType="primary"  okText={<a onClick={this.viewContact}
     
     type="primary">Done </a>} cancelText={<a onClick={this.viewContact}
     
     type="ghost">Close </a>}>


<Row gutter={[12,12]}>
<Col style={{'fontWeight':'bold'}}> Item Phone No: </Col> <Col>{selectItem.itemTel} <PhoneOutlined />  </Col>

 </Row>

 <Row gutter={[12,12]}>
<Col style={{'fontWeight':'bold'}}> Whatsapp Contact: </Col> <Col>{selectItem.whatsapp_no} <WhatsAppOutlined />  </Col>

 </Row>

<Row gutter={[12,12]}>
<Col style={{'fontWeight':'bold'}}> E-mail: </Col> <Col>{selectItem.itemEmail} </Col>

 </Row>


<Row gutter={[12,12]}>
<Col style={{'fontWeight':'bold'}}> Store Phone No: </Col> <Col>{selectItem.storeTel} <PhoneOutlined />  </Col>

 </Row>



            </Modal>
            :<></>
}


{cartData ?



<Card>

<h2 className='cart-det'> {Object.keys(cartData).length +" ITEM(S) AVAILABLE IN CART"}</h2>





{cartData ?

  cartData.map((data,index)=>(   

<>

<Row gutter={[12,12]} key={index} className="cart-data-row">


<Col span={6}>

<div>
<img alt="first image" style={{"display":"inlineToBlock"}} src={"http://127.0.0.1:8000"+data.images[0].images} />
</div>
</Col>


<Col span={12}>
<a
   onClick={e=>{
    

        document.location = '/property/views/'+data.id;    }
  }>
<Typography.Text ellipsis style={{'fontWeight':'bold','fontSize':'16px'}}>{data.title} </Typography.Text> <br/>
<span> <Rate  value={cartData.submit_user.rate} allowClear={false} disabled> </Rate> ({cartData.submit_user.rate_count}) </span> <br/>
<pre style={{'color':'black'}}>{data.description} </pre>
<Typography.Text style={{'color':'red'}}> {data.instock} item(s) in Stock</Typography.Text><br/>
<Typography.Text ellipsis>{data.address}  </Typography.Text>
</a>
</Col>

<Col span={6}>
{data.from_price != 0 ? <>
<Statistic  prefix={"₦"} value={data.from_price}></Statistic>  <span style={{
  'fontWeight':'bolder'
}}> - </span>
<Statistic prefix={"₦"} value={data.to_price}></Statistic> 

</>:
<Statistic prefix={"₦"} value={data.price}></Statistic> }

<p></p>
<Button type="primary" className="cart-btn"  onClick={e=>{

const valueData ={};
valueData.title = data.title;
valueData.phone_no= data.phone_no;
valueData.email = data.email;
valueData.storeTel = cartData[0].submit_user.phone_no
valueData.whatsapp_no = data.whatsapp_no


  this.viewContact(valueData);}} >View contact </Button>
  <p></p>
<Button type="ghost" className="cart-btn remCart" onClick={e=>this.removeFromCart(cartData[0].id,data.id)} >
<CloseOutlined/> Remove </Button>

</Col>

</Row>



<hr style={{'opacity':'0.3'}}/>

</>

)
  )



: <Empty description="No available item(s) you may like">

</Empty>}


{this.state.maylike ?
  <Pagination pageSize={pagesize}  
showTotal={(e,i)=>("Total "+e + " item(s)")} onChange={(page,pagesize)=>{
this.change(page, pagesize)
}} total={Object.keys(maylike).length} responsive={true} />
:<p></p>}





</Card>

 : <Empty description="You have no item in your Cart ">

</Empty>}





 



{cartData ?
<Tabs tabPosition="top"  defaultActiveKey="maylike" type="card">


<Tabs.TabPane key="maylike" tab={"RECOMMEND ITEMS"} >



<ul className='cart-reco'>

{this.state.maylike ?

  paginatedList.map((data,index)=>(   <a
   onClick={e=>{
      // this.props.toView(value);

        document.location = '/property/views/'+data.id;    }
  }><li key={index} >

<p><img key={index} className="data-images" style={{'width':'170px','height':'155px'}}
 src={BASE_IMG_URL+data.images[0].images}></img> </p>

 <Typography.Text ellipsis className='title'>{data.title} </Typography.Text>
<p className='price'>{data.from_price != 0 ? <>
<Statistic  prefix={"₦"} value={data.from_price}></Statistic>  <span className='space'> -  </span>
<Statistic prefix={"₦"} value={data.to_price}></Statistic> 

</>:
<Statistic prefix={"₦"} value={data.price}></Statistic> } </p>
<p className="new" style={{'color':'red'}}>New </p>


  </li></a>)
  )



: <Empty description="No available item(s) you may like">

</Empty>}


</ul>



</Tabs.TabPane>

</Tabs>
 : <Empty description="You have no item in your Cart ">

</Empty>}









    
    </div>

}

