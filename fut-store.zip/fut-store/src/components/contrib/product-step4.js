


import React, { Component,useState } from 'react';
import ReactDOM from 'react-dom';
import "antd/dist/antd.css"
import {Input,Button,Row,Col,Form,Divider,Radio,Select,
Upload,Modal, Alert, Steps, InputNumber,Collapse,Cascader,Typography} from "antd";
import {InfoCircleOutlined, UploadOutlined,PlusCircleOutlined,
  HomeOutlined,LoadingOutlined,FileImageOutlined,UpCircleOutlined,WhatsAppOutlined,
CarOutlined,PayCircleOutlined,CheckOutlined} from '@ant-design/icons';

import {useSelector} from 'react-redux'



const Step4=({handlechange, state})=>{

	const data= useSelector(state=>state.sHubInputs)


return <div className="delivery-upload animated zoomIn">

 <h2 className='add-detl'> DELIVERY OPTION(S) </h2>
 <hr className="divider" />
 
<div className="deli-input">
<label className="deli-label" htmlFor="delivery">With Delivery: </label> <br/>

<Radio.Group  onChange={e=>handlechange(e,'delivery')}  name="delivery" 
defaultValue={data['delivery']? data['delivery']:"no"} buttonStyle="outline">

<Radio value="yes">Yes</Radio><Radio value="no">No</Radio>

</Radio.Group>


</div>



<div className="deli-input">

<label className="deli-label"  htmlFor="deli-comp">Delivery Channel</label> <br/>


<Select className="deli-comp" onChange={(value)=>handlechange(value,"delivery_comp")}
 placeholder={data['delivery_comp']? data['delivery_comp']: "Delivery Company"}
 >
<Select.Option value="FedEx">FedEx</Select.Option>
<Select.Option value="Other">Other</Select.Option>

</Select> 

</div>
</div>

}

export default Step4