import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import { withRouter } from 'react-router-dom'

import { connect } from 'react-redux'




export default function(ComponentToBeRendered) {

    class Authenticate extends Component {
        componentWillMount() {
            if (!this.props.isAuthenticated) {
                this.props.history.push('/login');
            }
        }

        componentWillUpdate(nextProps) {
            if (!nextProps.isAuthenticated) {
                this.props.history.push('/login');
            }
        }

        render() {
            return ( <
                ComponentToBeRendered {...this.props }
                />
            );
        }
    }

    function mapStateToProps(state) {
        return {
            isAuthenticated: state.User.authenticated
        };

    }

    return withRouter(connect(mapStateToProps)(Authenticate));
}





// export default function(CompToRendered){
    


//     const mapStateToProps= (state, props)=>({
    
//         isAuthenticated:state.User.authenticated
//     })


//     class Authenticate extends Component {

//         constructor(props){
//             super(props)
//             this.state={
//                 loginUrl:"/login"
//             }

                       
//         }

//         componentWillMount(){

//             if(!this.props.isAuthenticated){
//                 this.props.history.push(this.state.loginUrl)
//                 console.log("to login")
//             }
//         }

//         componentWillUpdate(nextProps){

//             if(!nextProps.isAuthenticated){
//                 this.props.history.push(this.state.loginUrl)
//             }

//         }

//         render(){


//             return(

//                 <CompToRendered {...this.props}></CompToRendered>

     
//             )
//         }


//     }

//     return withRouter(connect(mapStateToProps, f=>f)(Authenticate))


// }