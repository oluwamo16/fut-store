
import React, {Component} from "react"
import ReactDOM from 'react-dom';
import "antd/dist/antd.css"
import {Button,Modal,Alert,Avatar,Carousel} from "antd";
import {LoadingOutlined,EditOutlined} from '@ant-design/icons';
import {connect,useSelector,useDispatch} from 'react-redux'
import PropTypes from 'prop-types'
import {withRouter,Redirect} from 'react-router-dom'
import {setFinishLoad,setImgUploadStat,setVerifyState,uploadStoreItem} from '../../actions/storehub'
import {bigload} from './beboloading'
import Home from "../navigation/home"






const UploadDone=({history})=><Modal visible={true} centered 
          title="Success"  okType="primary" okText={
          <a onClick={e=>{
          e.preventDefault();
          
            history.push('/dashboard')}}> Go to Dashboard </a>

               } cancelText={<a onClick={e=>{e.preventDefault();
             
            

                document.location='/submitProperty'  }} type="ghost">Upload more </a>}>

          <Alert showIcon type="success" message="Item upload successfully" ></Alert>
          <p> You can upload more item(s), or go to Dashboard</p>
          <Home label="Shop now..." />

                      </Modal>


export default withRouter(UploadDone)