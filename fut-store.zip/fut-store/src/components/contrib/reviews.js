import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import "antd/dist/antd.css"
import {Carousel,Divider,Button,Comment,Avatar} from 'antd';
import PropTypes from 'prop-types'
import {BASE_IMG_URL} from '../../settings'








const Review=({content=[]})=>{

    // console.log('content '+Object.keys(content))

    return (
    
        <>

{content.map((data,index)=> (

  <Comment datetime={data.created}
 style={{"textAlign":"left"}} author={data.account.user.username}
  avatar={<Avatar src={BASE_IMG_URL+data.account.image} style={{"width":'35px',
'height':'35px'}} className="avatar"><h2 style={{
  'color':'white'
}}>{data.account.user.username[0]}</h2></Avatar>}


 content={data.text}> 
 


 </Comment>

	))}

  
  

    
        </>
    )
    
    }


export default Review

Review.propTypes = {
 
        content:PropTypes.array,     
      
    }





