
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import "antd/dist/antd.css"
import {Avatar, Button,Divider,Table, Statistic,Row,Col,
  Tabs,Breadcrumb,Empty,Pagination,Rate,Comment,Input,Form,Typography,Modal,Card} from 'antd';
import {HomeOutlined,UserOutlined,LoadingOutlined,LikeOutlined,
  ArrowRightOutlined,CloseOutlined,PhoneOutlined,WhatsAppOutlined } from '@ant-design/icons';
import {connect} from 'react-redux'
import PropTypes from 'prop-types'
import {withRouter} from 'react-router-dom'

import {setToViewStatus,youMayLike} from "../../actions/rent_to_view"
import {getCart,removeFromCart,cartRecommend} from "../../actions/cart"
import RentImg from '../contrib/rentimages'
import Review from '../contrib/reviews'
import "../../css/viewrent.css";

import Home from "../navigation/home"
import SubmitProperty from "../contrib/submitproperty"
import {updateAjaxRoute} from '../../actions/ajaxroute'
import {get_current_address} from "../../actions/location"
import "../../css/cart.css"
import {BASE_IMG_URL} from '../../settings'
import {last} from 'lodash'







const mapStateToProps= (state, props)=>({
    
	routeStatus:state.ajaxRoute.status,
  to_view:state.toView,
   user:state.User
   
})





  class Cart extends Component{
        
    
    constructor(props){
    super(props)
    this.state={
      data:{},
      views:1,
      page:1,
      pagesize:8,

      contact:false
    }

  
}


componentDidMount(){


document.title = 'Cart: '+this.props.match.params.username;

this.props.updateAjaxRoute(true)

this.props.getCart(this.props.match.params.username).then(res=>{
 
  this.setState({
    ...this.state,
    cartData:res.data
  })

this.props.updateAjaxRoute(false)

if (res.data){
this.cartCategory(res.data)

} 
  
})


// const category = 'this.cartCategory()'


 // this.state.cartData && this.cartCategory(this.state.cartData)






}


cartCategory=(dataVal=[])=>{



   var returnData=[];
   const excludeData=[]

   const data = dataVal

    Object.keys(data).forEach(
        prop =>{

         returnData.push(data[prop]['category']);
         excludeData.push(data[prop]['id']);
       });

    
const sendData = {
  address:this.props.get_current_address(),
  category:returnData,
  excludeData
}


  this.props.cartRecommend(sendData).then(res=>{

// console.log('view---'+res.data.view)
  this.setState({
    ...this.state,
    maylike:res.data
  })


})



}

removeFromCart=(cartId,itemId)=>{

this.props.updateAjaxRoute(true)

this.props.removeFromCart(cartId,itemId).then(res=>{
 
  this.setState({
    ...this.state,
    cartData:res.data
  })

this.props.updateAjaxRoute(false)
  
})


}

viewContact=(data)=>{

  this.setState({
    ...this.state,
    contact:!this.state.contact,
    selectItem:data ? {
      title:data.title,
      itemTel:data.phone_no,
      whatsapp_no:data.whatsapp_no,
      itemEmail:data.email,
      storeTel:data.storeTel

    }:{}
  })




}




paginate=(page=1, pagesize=10,data=[])=>{

  
    const splicelist = data.slice((page*pagesize)-pagesize, ((page*pagesize)));
  
    return splicelist;
       
 
  }

  pageChange=(page, pagesize)=>{

    this.setState({...this.state, page})
  }

handlechange =()=>{

  ;
}

    
    render(){

  const {routeStatus,history} = this.props;
  const {cartData,maylike,page, pagesize,selectItem} = this.state





// const paginatedList = this.paginate(page,pagesize,maylike)

const paginatedList = maylike
const {username} = this.props.match.params;



// console.log("cartdata: "+ Object.keys(cartData))





      return (

        <>






<p className="cart-top-det"> <span className="your-cart"> YOUR CART </span>

<Button className="cont-shop" onClick={e=>this.props.history.push('/')}>Continue Shopping </Button>
 </p>



{routeStatus ? <p className="down-div">Loading <LoadingOutlined spin></LoadingOutlined></p>:







<div className="down-div">

{selectItem ? 

  <Modal closable={false}  visible={this.state.contact} centered title={<h2>Contact information for ({selectItem.title})</h2>}  okType="primary"  okText={<a onClick={this.viewContact}
     
     type="primary">Done </a>} cancelText={<a onClick={this.viewContact}
     
     type="ghost">Close </a>}>


<Row gutter={[12,12]}>
<Col style={{'fontWeight':'bold'}}> Item Phone No: </Col> <Col>{selectItem.itemTel} <PhoneOutlined />  </Col>

 </Row>

 <Row gutter={[12,12]}>
<Col style={{'fontWeight':'bold'}}> Whatsapp Contact: </Col> <Col>{selectItem.whatsapp_no} <WhatsAppOutlined />  </Col>

 </Row>

<Row gutter={[12,12]}>
<Col style={{'fontWeight':'bold'}}> E-mail: </Col> <Col>{selectItem.itemEmail} </Col>

 </Row>


<Row gutter={[12,12]}>
<Col style={{'fontWeight':'bold'}}> Store Phone No: </Col> <Col>{selectItem.storeTel} <PhoneOutlined />  </Col>

 </Row>



            </Modal>
            :<></>
}


{cartData ?



<div className='cart-dt'>

<h2 className='cart-det'> {Object.keys(cartData).length +" ITEM(S) AVAILABLE IN CART"}</h2>





{Object.keys(cartData).length > 0 ?

  cartData.map((data,index)=>(   

<>
{data && <Row gutter={[12,12]} key={index} className="cart-data-row">


<Col span={6}>

<div>

{last(data.images) && <img alt="first image" style={{"display":"inlineToBlock"}} 
src={BASE_IMG_URL+last(data.images).images} />
}
</div>
</Col>


<Col span={12}>
<a
   onClick={e=>{
    

        document.location = '/property/views/'+data.id;    }
  }>
<Typography.Text ellipsis style={{'fontWeight':'bold','fontSize':'17px'}}>
{data.title} </Typography.Text> <br/>
<span> <Rate  value={cartData[0].submit_user.rate} allowClear={false} disabled> </Rate> 
({cartData[0].submit_user.rate_count}) </span> <br/>
<Typography.Text ellipsis style={{'fontSize':'16px'}}>
{data.category} </Typography.Text> <br/>
<pre style={{'color':'black'}}>{data.description} </pre>
<Typography.Text style={{'color':'red'}}> {data.instock} item(s) in Stock</Typography.Text><br/>
<Typography.Text ellipsis>{data.address}  </Typography.Text>
</a>
</Col>

<Col span={6}>
{data.from_price != 0 ? <>
<Statistic  prefix={"₦"} value={data.from_price}></Statistic>  <span style={{
  'fontWeight':'bolder'
}}> - </span>
<Statistic prefix={"₦"} value={data.to_price}></Statistic> 

</>:
<Statistic prefix={"₦"} value={data.price}></Statistic> }

<p></p>
<Button type="primary" className="cart-btn"  onClick={e=>{

const valueData ={};
valueData.title = data.title;
valueData.phone_no= data.phone_no;
valueData.email = data.email;
valueData.storeTel = cartData[0].submit_user.phone_no
valueData.whatsapp_no = data.whatsapp_no


  this.viewContact(valueData);}} >View contact </Button>
  <p></p>
<Button type="ghost" className="cart-btn remCart" onClick={e=>this.removeFromCart(username,data.id)} >
<CloseOutlined/> Remove </Button>

</Col>

</Row>

}

<hr style={{'opacity':'0.3'}}/>



</>

)
  )



: <Empty description="No available item(s) in your cart">

</Empty>}





</div>

 : <Empty description="You have no item in your Cart ">

</Empty>}





 



{cartData ?
<Tabs tabPosition="top"  defaultActiveKey="maylike" type="card">


<Tabs.TabPane key="maylike" tab={"RECOMMEND ITEMS"} >



<ul className='cart-reco'>

{this.state.maylike ?

  paginatedList.map((data,index)=>(   <a
   onClick={e=>{
      // this.props.toView(value);

        document.location = '/property/views/'+data.id;    }
  }><li key={index} >

<p><img key={index} className="data-images" style={{'width':'170px','height':'155px'}}
 src={BASE_IMG_URL+data.images[0].images}></img> </p>

 <Typography.Text ellipsis className='title'>{data.title} </Typography.Text>
<p className='price'>{data.from_price != 0 ? <>
<Statistic  prefix={"₦"} value={data.from_price}></Statistic>  <span className='space'> -  </span>
<Statistic prefix={"₦"} value={data.to_price}></Statistic> 

</>:
<Statistic prefix={"₦"} value={data.price}></Statistic> } </p>
<p className="new" style={{'color':'red'}}>New </p>


  </li></a>)
  )



: <Empty description="No available item(s) in your cart">

</Empty>}


</ul>



</Tabs.TabPane>

</Tabs>
 : <Empty description="You have no item in your Cart ">

</Empty>}









    
    </div>

}




</>
      )

    }
  }

  
 
  

  
  
  export default withRouter(connect(mapStateToProps,{get_current_address,cartRecommend,updateAjaxRoute,setToViewStatus,getCart,removeFromCart})(Cart))

Cart.propTypes = {
 
      routeStatus:PropTypes.bool,   
      to_view:PropTypes.object  
    
  }