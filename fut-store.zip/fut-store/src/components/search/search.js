
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import "antd/dist/antd.css"
import {Input,Button,Collapse,Cascader,Alert,Typography} from "antd";
import {SearchOutlined,LoadingOutlined,ClearOutlined,MenuFoldOutlined,
MenuUnfoldOutlined} from '@ant-design/icons';
import {connect} from 'react-redux'
import PropTypes from 'prop-types'
import {withRouter} from 'react-router-dom'
import {search,getSuggestion,filterSearch} from "../../actions/search"
import {updateAjaxRoute} from '../../actions/ajaxroute'
import Options from "../contrib/category_option"
import {handleFilterClick,setFilterToggle} from '../../actions/filter'
import {get_current_address} from "../../actions/location"
import {setToHome} from '../../actions/contrib'
import Home from "../navigation/home"

import "../../css/search.css"





// const mapDispatchToProps=dispatch =>({
//     onclick:f=>f
//     })
    
    const mapStateToProps= (state, props)=>({
    
        user:state.User,
        searchFilterVal:state.searchData,
        filToggleVal:state.filterToggleStat
    })

    


  class Search extends Component{
        
    
    constructor(props){
    super(props)
    this.state={
        searchValue:"",
        load:false,
        category:"all",
        search:''
    }
}


componentDidMount(){

  this.props.setFilterToggle('left')
}

search=()=>{

    document.title="You search for: "+this.state.search
}

handleSearch=()=>{
  

       const newData = {category:this.state.category? this.state.category:"all",
search:this.state.search ? this.state.search: ""}



this.props.getSuggestion(newData).then(res=>{
 
  this.setState({
    ...this.state,
    load:false,
    suggestion:res.data
  })

  
})



}

suggClear=(e)=>{

    this.setState({...this.state,
        suggestion:[]})

}



handleChange=(e,type)=>{
    
  // console.log(type+'----'+e)

    this.setState({...this.state,
        load:true})

// this.handleSearch();


switch (type) {

  
    case "category":{

      this.setState({
          ...this.state,category:Object.values(e)[1]
      })

          break;
    }


       case "search":{

      this.setState({
          ...this.state,search:e.target.value
      },this.searchData(e.target.value))

    
          break;
    }
      

     
      
      default:
          break;
}




}

searchData=(e)=>{


const newData = {...this.state,
click:e,
filtername:"You search for: "+ (e ? e:"All"),
category:this.state.category}
 

 this.setState({
          ...this.state,suggestion:null,
          search:e
      })


handleFilterClick(this.props,newData,"search_data")



}

toggleBtn=(btn)=>{

const { _left, _right } = this.refs


this.props.setFilterToggle(btn)

}



    
    render(){


// const {user,search,history } = this.props
const {suggestion} = this.state

const {filToggleVal} = this.props

  
      return (
<>
<div  className="search-input">
          <span className="filter-ico">
 { filToggleVal =='left' ? <MenuFoldOutlined ref="_left" className="left-btn" onClick={e=>this.toggleBtn('right')} />:
<MenuUnfoldOutlined ref="_right" className="right-btn" onClick={e=>this.toggleBtn('left')}  />
       }  </span>  

        <Input  className="input" allowClear style={{"width":"50%"}}
        onChange={(e)=>this.handleChange(e,"search")}
        placeholder="Search for anything on beBO" 
        />  
<SearchOutlined className='search-logo'   onClick={e=>this.searchData(this.state.search)} />

       

<i className='search-cascade'>
<Cascader  className="input search-cascader" style={{'width':'180px'}}
displayRender={(e,f)=>e } expandTrigger="hover" 
placeholder="Shop by category" options={Options} 
onChange={e=>this.handleChange(e,'category')} />
</i>

</div>
<div className="suggestion" style={{'backgroundColor':'white',
  'display':'absolute',"position":'fixed','z-index':'1000','overflow-y':'scroll'}}  >  

 {suggestion && Object.keys(suggestion).length > 0 &&  <p onClick={this.suggClear}> <ClearOutlined /> </p>}

{ suggestion ?



suggestion.map((data,index)=>(



<Typography.Paragraph key={index}  onClick={e=>this.searchData(data.text)}>

<Typography.Text ellipsis style={{'fontWeight':'bold','fontSize':'14px'}}>{data.text} </Typography.Text> <br/>



<hr style={{'opacity':'0.5px'}} />
 </Typography.Paragraph>
 





  )


)





 : suggestion === [] &&
  <Alert showIcon type="success" message="No suggestion found" ></Alert>

}

</div>
        </>

      )

    }
  }

  
 
  

  
  
  export default withRouter(connect(mapStateToProps,{setFilterToggle,setToHome,search,getSuggestion,updateAjaxRoute,get_current_address,handleFilterClick,filterSearch})(Search))

  Search.propTypes = {
      user: PropTypes.object.isRequired,
      search:PropTypes.func.isRequired,
      searchFilterVal:PropTypes.object.isRequired,
      updateAjaxRoute:PropTypes.func.isRequired,
      getSuggestion:PropTypes.func.isRequired,
      
  }