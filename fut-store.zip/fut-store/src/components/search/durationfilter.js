
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import "antd/dist/antd.css"
import {Radio} from "antd";
import {FieldTimeOutlined} from '@ant-design/icons';
import {connect} from 'react-redux'
import PropTypes from 'prop-types'
import {withRouter} from 'react-router-dom'
import {updateAjaxRoute} from '../../actions/ajaxroute'
import {filterSearch} from "../../actions/search"
import {handleFilterClick} from '../../actions/filter'
import {get_current_address} from "../../actions/location"
import {setToHome} from '../../actions/contrib'




// const mapDispatchToProps=dispatch =>({
//     onclick:f=>f
//     })
    
    const mapStateToProps= (state, props)=>({
    
        searchFilterVal:state.searchData
    })

    


  class DurationFilter extends Component{
        
    
    constructor(props){
    super(props)

  
}



handleChange=(e)=>{

const newData = {...this.state,
click:e.target.value,
filtername:"Filter by duration: "+e.target.value}

handleFilterClick(this.props,newData,"duration")

}
    
    
    render(){



      return (
<div className="price" >

<p style={{'fontWeight':'bolder'}}> Duration <FieldTimeOutlined></FieldTimeOutlined> </p>
<Radio.Group onChange={e=>this.handleChange(e)}   defaultValue="none" buttonStyle="solid">
<Radio value="none"> None</Radio><br/>
<Radio value="weekly"> Weekly</Radio><br/>
<Radio value="monthly"> Monthly</Radio><br/>
<Radio value="yearly"> Yearly</Radio>

</Radio.Group>



        </div>

      )

    }
  }

  
 
  

  
  
  export default withRouter(connect(mapStateToProps,{setToHome,filterSearch,updateAjaxRoute,get_current_address,handleFilterClick})(DurationFilter))

  DurationFilter.propTypes = {
 
      filterSearch:PropTypes.func.isRequired,     
      searchFilterVal:PropTypes.object.isRequired,
      updateAjaxRoute:PropTypes.func.isRequired,
      
  }