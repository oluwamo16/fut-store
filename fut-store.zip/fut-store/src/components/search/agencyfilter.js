
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import "antd/dist/antd.css"
import {Radio,Empty,Avatar} from "antd";
import {HeatMapOutlined} from '@ant-design/icons';
import {connect} from 'react-redux'
import PropTypes from 'prop-types'
import {withRouter} from 'react-router-dom'
import {getTopCompany} from "../../actions/agency"
import {filterSearch} from "../../actions/search"
import {updateAjaxRoute} from '../../actions/ajaxroute'
import {handleFilterClick} from '../../actions/filter'
import {get_current_address} from "../../actions/location"
import {setToHome} from '../../actions/contrib'
import {BASE_IMG_URL} from '../../settings'
import {shuffle} from 'lodash'



// const mapDispatchToProps=dispatch =>({
//     onclick:f=>f
//     })
    
    const mapStateToProps= (state, props)=>({
    
        searchFilterVal:state.searchData
    })

    


  class AgencyFilter extends Component{
        
    
    constructor(props){
    super(props);
    this.state={
   bgStyles:[
'golden','red','green','silver','blue']
    }

  
}
UNSAFE_componentWillMount(){

this.props.getTopCompany().then(res=>{

  const data = res.data

  this.setState({
    ...this.state,
    getTopCompany:data
  })
})

}


handleClick=(e)=>{

const newData = {...this.state,
click:e,
filtername:"Filter by shop: "+e}

handleFilterClick(this.props,newData,"store")

}
    
    render(){

// console.log('city '+this.props.city())

const {getTopCompany} = this.state

      return (
<div className="agency" >

<p style={{'fontWeight':'bolder'}}> Shops</p>

<div  className="address">
<ul style={{'paddingLeft':'0px',
'overflowY':'scroll','overflow-x':'hidden'}}>

{getTopCompany ? getTopCompany.map((e,index)=>(
    <li 
    key={index} onClick={f=>this.handleClick(e.agencyname)} style={{'listStyle':'none',
    'marginLeft':'0px'}} > 
    <Avatar  src={e.image && BASE_IMG_URL+e.image} 
    style={{"width":'35px','height':'35px',
  'marginTop':'10px'}} className="avatar"><h2 style={{
  'color':'white'
}}>{e.agencyname.slice(0,2)}</h2></Avatar> {e.agencyname}</li>
)) : <Empty description="No Shops Available">
Company (0) found
</Empty>

}



</ul>
</div>

        </div>

      )

    }
  }

  
 
  

  
  
  export default withRouter(connect(mapStateToProps,{setToHome,filterSearch,getTopCompany,updateAjaxRoute,get_current_address,handleFilterClick})(AgencyFilter))

  AgencyFilter.propTypes = {
 
      filterSearch:PropTypes.func.isRequired,     
      searchFilterVal:PropTypes.object.isRequired,
      getTopCompany:PropTypes.func.isRequired,
      updateAjaxRoute:PropTypes.func.isRequired,
      
  }