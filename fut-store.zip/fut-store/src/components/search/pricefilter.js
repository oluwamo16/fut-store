
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import "antd/dist/antd.css"
import {Button,Slider,InputNumber,Radio,Typography} from "antd";
import {} from '@ant-design/icons';
import {connect} from 'react-redux'
import PropTypes from 'prop-types'
import {withRouter} from 'react-router-dom'
import {updateAjaxRoute} from '../../actions/ajaxroute'
import {filterSearch} from "../../actions/search"
import {handleFilterClick} from '../../actions/filter'
import {get_current_address} from "../../actions/location"
import {setToHome} from '../../actions/contrib'





// const mapDispatchToProps=dispatch =>({
//     onclick:f=>f
//     })
    
    const mapStateToProps= (state, props)=>({
    
        searchFilterVal:state.searchData
    })

    


  class PriceFilter extends Component{
        
    
    constructor(props){
    super(props)
    this.state={

    }
  
}


setValue=(e,type='slider')=>{
console.log('set value '+e+' - type: '+type)
switch(type){

  case 'slider':{

this.setState({...this.state,min:0,max:e})
break;
  }


  case 'min':{

    this.setState({...this.state,min:e})
    break;
      }

    case 'max':{

      this.setState({...this.state,max:e})
      break;
        }
}

}

handleApply=(e)=>{

const newData = {...this.state,
click:[this.state.min,this.state.max],
filtername:"Filter by price ₦: " +this.state.min + " to "+this.state.max}



handleFilterClick(this.props,newData,"configprice")

}

handleChange=(e)=>{

const newData = {...this.state,
click:e.target.value,
filtername:"Filter by price ₦: " +e.target.value}


handleFilterClick(this.props,newData,"price")

}
    



    
    render(){



      return (
<div className="price" >

<table>
<thead>
  <td style={{'fontWeight':'bolder','marginBottom':'5px'}} 
    >Price (₦)    </td>
</thead>
<tbody>

<tr>
<Radio.Group  onChange={e=>this.handleChange(e)}   defaultValue="any price" buttonStyle="solid">

<Radio value="any price"><Typography.Text ellipsis >Any price </Typography.Text>  </Radio><br/>
<Radio value="under 1000"><Typography.Text ellipsis >Under ₦ 1000</Typography.Text> </Radio><br/>
<Radio value="1000 to 10000"><Typography.Text ellipsis >₦ 1000 to ₦ 10000</Typography.Text> </Radio><br/>
<Radio value="10000 to 50000"><Typography.Text ellipsis >₦ 10000 to ₦ 50000</Typography.Text> </Radio><br/>
<Radio value="over 50000"><Typography.Text ellipsis >Over ₦ 50000</Typography.Text> </Radio><br/>

</Radio.Group>


</tr>


<tr  style={{'marginTop':'15px'}}>
<td >

<InputNumber placeholder="Low" decimalSeparator=',' onChange={e=>this.setValue(e,'min')}  >
</InputNumber>
<InputNumber placeholder="High" onChange={e=>this.setValue(e,'max')}  ></InputNumber>
</td>

</tr> </tbody>


</table>


<Button className="price-apply" onClick={this.handleApply}> Apply </Button>
        </div>

      )

    }
  }

  
 
  

  
  
  export default withRouter(connect(mapStateToProps,{setToHome,get_current_address,handleFilterClick,filterSearch,updateAjaxRoute})(PriceFilter))

 PriceFilter.propTypes = {
 
      filterSearch:PropTypes.func.isRequired,     
      searchFilterVal:PropTypes.object.isRequired,
      updateAjaxRoute:PropTypes.func.isRequired,
      
  }