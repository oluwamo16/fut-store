
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import "antd/dist/antd.css"
import {Radio,Empty} from "antd";
import {EnvironmentOutlined} from '@ant-design/icons';
import {connect} from 'react-redux'
import PropTypes from 'prop-types'
import {withRouter} from 'react-router-dom'
import {city} from "../../actions/location"
import {filterSearch} from "../../actions/search"
import {updateAjaxRoute} from '../../actions/ajaxroute'
import {handleFilterClick} from '../../actions/filter'
import {get_current_address} from "../../actions/location"
import {setToHome} from '../../actions/contrib'




// const mapDispatchToProps=dispatch =>({
//     onclick:f=>f
//     })
    
    const mapStateToProps= (state, props)=>({
    
        searchFilterVal:state.searchData
    })

    


  class LocationFilter extends Component{
        
    
    constructor(props){
    super(props)

  
}




handleChange=(e)=>{

const newData = {...this.state,
click:e.target.value,
filtername:"Filter by location: "+e.target.value}

handleFilterClick(this.props,newData,"location")

}
    
    render(){

// console.log('city '+this.props.city())

      return (
<div className="location" >

<p style={{'fontWeight':'bolder'}}> Location <EnvironmentOutlined></EnvironmentOutlined></p>

<div  className="address">
<Radio.Group onChange={e=>this.handleChange(e)}    buttonStyle="outline">

{this.props.city() ? this.props.city().map((e,index)=>(
    <Radio key={index} value={e}> {e}</Radio>
)) : <Empty description="No City Available">
City (0) found
</Empty>

}



</Radio.Group>
</div>

        </div>

      )

    }
  }

  
 
  

  
  
  export default withRouter(connect(mapStateToProps,{setToHome,filterSearch,city,updateAjaxRoute,get_current_address,handleFilterClick})(LocationFilter))

  LocationFilter.propTypes = {
 
      filterSearch:PropTypes.func.isRequired,     
      searchFilterVal:PropTypes.object.isRequired,
      city:PropTypes.func.isRequired,
      updateAjaxRoute:PropTypes.func.isRequired,
      
  }