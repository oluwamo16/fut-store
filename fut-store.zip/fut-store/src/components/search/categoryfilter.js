
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import "antd/dist/antd.css"
import {Tag,Pagination,Select} from "antd";
import {} from '@ant-design/icons';
import {connect} from 'react-redux'
import PropTypes from 'prop-types'
import {withRouter} from 'react-router-dom'
import {setFilter,handleFilterClick} from "../../actions/filter"
import {filterSearch, setSearchPref,search,dailyDeals} from "../../actions/search"
import {updateAjaxRoute} from '../../actions/ajaxroute'
import {setToHome} from '../../actions/contrib'

import {get_current_address} from "../../actions/location"
import "../../css/filter.css"





// const mapDispatchToProps=dispatch =>({
//     onclick:f=>f
//     })
    
    const mapStateToProps= (state, props)=>({
    
        filterTag:state.filterData.data,
        mainData:state.MainData,
        searchFilterVal:state.searchData
    })

    


  class FilterCategory extends Component{
        
    
    constructor(props){
    super(props)
    this.state={
        click:'All',
        page:1,
        pagesize:50,
      }
  
}



paginate=(page=1, pagesize=50,data=[])=>{

  
    const splicelist = data.slice((page*pagesize)-pagesize, ((page*pagesize)));
  
    return splicelist;
       
 
  }

// componentWillMount(){

//      this.props.setFilter(this.props.mainData,'category')
//     // this.props.setSearchPref()

// }


change=(e)=>{

    
    this.setState({click:e.k})

    
}

  pageChange=(page, pagesize)=>{

    this.setState({...this.state, page})
  }

handleClickTag=(data)=>{
   this.props.setFilter(this.props.mainData,'category')
   

   const newData = {...this.state,
click:data,
filtername:"Category:  "+data}


handleFilterClick(this.props,newData,"tag")
    
}
    
    render(){


const {filterTag } = this.props

// console.log('filter Tag-data=> ',Object.values(filterTag))

 // const {routeStatus, filtername,maindata,history} = this.props;

const {page, pagesize} = this.state;

const paginatedList = this.paginate(page,pagesize,filterTag)




      return (
<div className="ta-category animated fadeIn" >

<Select  className="category-type" onChange={(value)=>this.handleClickTag(value)} placeholder="Select category"
 
>




    {filterTag ? paginatedList.map((k,index)=>(
   <Select.Option value={k}>{k}</Select.Option>
    ))
    : <span>No Cateory</span>}




    

    </Select> 



        </div>

      )

    }
  }

  
 
  

  
  
  export default withRouter(connect(mapStateToProps,{handleFilterClick,dailyDeals,search,get_current_address,setToHome,setFilter,updateAjaxRoute,filterSearch, setSearchPref})(FilterCategory))

  FilterCategory.propTypes = {
     
      setFilter:PropTypes.func.isRequired,
      filterSearch:PropTypes.func.isRequired,
      filterTag:PropTypes.array.isRequired,
      filterType:PropTypes.string,
      mainData:PropTypes.array,
      searchFilterVal:PropTypes.object.isRequired,
      setSearchPref:PropTypes.func.isRequired,
      updateAjaxRoute:PropTypes.func.isRequired,
      handleFilterClick:PropTypes.func.isRequired,
  
  }