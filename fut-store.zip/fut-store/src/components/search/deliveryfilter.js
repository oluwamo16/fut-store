
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import "antd/dist/antd.css"
import {Radio} from "antd";
import {} from '@ant-design/icons';
import {connect} from 'react-redux'
import PropTypes from 'prop-types'
import {withRouter} from 'react-router-dom'
import {updateAjaxRoute} from '../../actions/ajaxroute'
import {filterSearch} from "../../actions/search"
import {handleFilterClick} from '../../actions/filter'
import {get_current_address} from "../../actions/location"
import {setToHome} from '../../actions/contrib'




// const mapDispatchToProps=dispatch =>({
//     onclick:f=>f
//     })
    
    const mapStateToProps= (state, props)=>({
    
        searchFilterVal:state.searchData
    })

    


  class DeliveryFilter extends Component{
        
    
    constructor(props){
    super(props)
  
}

componentWillMount(){

}

handleChange=(e)=>{

const newData = {...this.state,
click:e.target.value,
filtername:"Filter by delivery: "+e.target.value}

handleFilterClick(this.props,newData,"delivery")

}
    
    render(){



      return (
<div className="delivery" >
<p style={{'fontWeight':'bolder'}}> With Delivery</p>
<Radio.Group  onChange={e=>this.handleChange(e)}  defaultValue="both">

<Radio value="yes">Yes</Radio><Radio value="no">No</Radio>
<Radio value="both">Both</Radio>

</Radio.Group>

        </div>

      )

    }
  }

  
 
  

  
  
  export default withRouter(connect(mapStateToProps,{setToHome,filterSearch,updateAjaxRoute,get_current_address,handleFilterClick})(DeliveryFilter))

  DeliveryFilter.propTypes = {
 
      filterSearch:PropTypes.func.isRequired,
      updateAjaxRoute:PropTypes.func.isRequired,     
      searchFilterVal:PropTypes.object.isRequired,
      
  }
  