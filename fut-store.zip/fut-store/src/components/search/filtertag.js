
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import "antd/dist/antd.css"
import {Tag,Pagination} from "antd";
import {} from '@ant-design/icons';
import {connect} from 'react-redux'
import PropTypes from 'prop-types'
import {withRouter} from 'react-router-dom'
import {setFilter,handleFilterClick} from "../../actions/filter"
import {filterSearch, setSearchPref,search,dailyDeals} from "../../actions/search"
import {updateAjaxRoute} from '../../actions/ajaxroute'
import {setToHome} from '../../actions/contrib'
import categoryData from '../../actions/tagoptions'

import {get_current_address} from "../../actions/location"
import "../../css/filter.css"





// const mapDispatchToProps=dispatch =>({
//     onclick:f=>f
//     })
    
    const mapStateToProps= (state, props)=>({
    
        filterTag:state.filterData.data,
        mainData:state.MainData,
        searchFilterVal:state.searchData
    })

    


  class FilterTag extends Component{
        
    
    constructor(props){
    super(props)
    this.state={
        click:'All',
        page:1,
        pagesize:7,
      }
  
}



paginate=(page=1, pagesize=7,data=[])=>{

  
    const splicelist = data.slice((page*pagesize)-pagesize, ((page*pagesize)));
  
    return splicelist;
       
 
  }

// componentWillMount(){

//      this.props.setFilter(this.props.mainData,'category')
//     // this.props.setSearchPref()

// }


change=(e)=>{

    
    this.setState({click:e.k ? e.k:e})

    
}

  pageChange=(page, pagesize)=>{

    this.setState({...this.state, page})
  }

handleClickTag=()=>{
   // this.props.setFilter(this.props.mainData,'category')
   

   const newData = {...this.state,
click:this.state.click,
filtername:"Category:  "+this.state.click}


handleFilterClick(this.props,newData,"tag")
    
}
    
    render(){


const {filterTag } = this.props

// console.log('filter Tag-data=> ',Object.values(filterTag))

 // const {routeStatus, filtername,maindata,history} = this.props;

const {page, pagesize} = this.state;

const paginatedList = this.paginate(page,pagesize,categoryData)




      return (
<div className="tag-category animated fadeIn" >

<span key={'All'}
      onMouseDown={e=>this.change('All')} onClick={this.handleClickTag}>

      <Tag className="tag all"    style={{
'borderRadius':"20px",'border':'0px solid',
'fontSize':'14px'
 }} >All</Tag> </span>




    {filterTag ? paginatedList.map((k,index)=>( <span  key={index} 
      onMouseDown={e=>this.change({k})} onClick={this.handleClickTag}>

      <Tag className="tag "    style={{
'borderRadius':"20px",'border':'0px solid',
'fontSize':'14px'
 }} >{k}</Tag> </span> ))
    : <span>No Tag</span>}

     {filterTag ?


<Pagination className="paginate" pageSize={pagesize} size="small" 
 onChange={(page,pagesize)=>{
this.pageChange(page, pagesize)
}} total={categoryData.length} responsive={true} />
 :<p></p>}

        </div>

      )

    }
  }

  
 
  

  
  
  export default withRouter(connect(mapStateToProps,{handleFilterClick,dailyDeals,search,get_current_address,setToHome,setFilter,updateAjaxRoute,filterSearch, setSearchPref})(FilterTag))

  FilterTag.propTypes = {
     
      setFilter:PropTypes.func.isRequired,
      filterSearch:PropTypes.func.isRequired,
      filterTag:PropTypes.array.isRequired,
      filterType:PropTypes.string,
      mainData:PropTypes.array,
      searchFilterVal:PropTypes.object.isRequired,
      setSearchPref:PropTypes.func.isRequired,
      updateAjaxRoute:PropTypes.func.isRequired,
      handleFilterClick:PropTypes.func.isRequired,
  
  }