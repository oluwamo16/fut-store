import React, {Component} from 'react'
import ReactDOM from "react-dom"


const NotFound = ()=>{
    return (

        <h2>
        first app on server
        </h2>
    )
}

export default NotFound;