
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import "antd/dist/antd.css"
import {Empty,List,Pagination,Card,Row,Col,Cascader,Typography} from "antd";
import {LoadingOutlined} from '@ant-design/icons';
import {connect} from 'react-redux'
import PropTypes from 'prop-types'
import {withRouter} from 'react-router-dom'
import {updateAjaxRoute} from '../actions/ajaxroute'
import {setToHome} from '../actions/contrib'
import {dailyDeals} from "../actions/search"
import ListViewRent from "./contrib/rentview"
import PopularCategory from "./contrib/popularcategory"
import SellRent from "./contrib/tinycomponents/sellRent"
import Shoes from "./contrib/tinycomponents/getshoes"
import Shops from "./contrib/allshops"
import Store from "./contrib/tinycomponents/trendingstore"
// import {FaceMask,CreateStore} from "./contrib/homepagecontrib"
import {get_current_address} from "../actions/location"
import {Sort} from "../actions/sort"
import {Route} from "react-router"

import "../css/mainview.css"



// const mapDispatchToProps=dispatch =>({
//     onclick:f=>f
//     })
    
    const mapStateToProps= (state, props)=>({
    
        filtername:state.filterName,
        maindata:state.MainData,
        routeStatus:state.ajaxRoute.status,
        isHome:state.isHome
    
       
    })

    


  class MainViewPage extends Component{
        
    
    constructor(props){
    super(props)

    this.state = {
        page:1,
        pagesize:30
      }

  
}

UNSAFE_componentWillMount(){
  document.title = "Get Electronics, Cars, Fashion | beBo.com"
  // this.props.setToHome(true)

    const newValue = {location:this.props.get_current_address()}
    this.props.updateAjaxRoute(true)
    this.props.dailyDeals(newValue)
}



paginate=(page=1, pagesize=30,data=[])=>{

  
    const splicelist = data.slice((page*pagesize)-pagesize, ((page*pagesize)));
  
    return splicelist;
       
 
  }

  pageChange=(page, pagesize)=>{

    this.setState({...this.state, page})
  }

handlechange =(sortFilter)=>{



this.props.Sort(this.props.maindata,sortFilter)


   

}

sortComp=(Options)=> <span>
    <Cascader className="sort" 
    displayRender={(e,f)=>e } expandTrigger="hover" 
    placeholder="Sort by: Recommended" options={Options} 
    onChange={e=>this.handlechange(e)} />

     </span>





    
    render(){

const {routeStatus, filtername,maindata,history,isHome,setToHome} = this.props;

const {page, pagesize,mainStateData} = this.state;

const paginatedList = this.paginate(page,pagesize, maindata)

const Options =[ {
      value: 'na',
      label: <Typography.Text>Sort by: Newest Arrivals</Typography.Text>,
       
    },{
      value: 'pl2h',
      label: <Typography.Text>Price: Low to High</Typography.Text>,
       
    },{
      value: 'ph2l',
      label: <Typography.Text>Sort by: High to Low</Typography.Text>,
       
    },{
      value: 'sr',
      label: <Typography.Text>Sort by: Rating Count</Typography.Text>,
       
    },
    {
      value: 'r',
      label: <Typography.Text>Sort by: Rating</Typography.Text>,
       
    },{
      value: 'il',
      label: <Typography.Text>Sort by: Item Like(s)</Typography.Text>,
       
    },]

      return (
<div className="mainview" >


{isHome &&
<>
<h1 className="find-tins" style={{'textAlign':'left'}}>Find things you'll love. Support independent sellers. Only on beBO  </h1>


<Row gutter={[12,]} >

<Col span={16} className="p-cat-col">
 <PopularCategory> </PopularCategory>
 <SellRent />

</Col>

<Col className="shoe-col" span={8}>
<Shoes></Shoes>
<Store />
</Col>

</Row>



 

  </>}


{routeStatus ? <p className='tiny-loading'>Loading <LoadingOutlined spin></LoadingOutlined></p>
: maindata &&
<>


<Card className="maindata">
<List style={{'backgroundColor':'white'}}>

<List.Item className="maindata-label">
<h3 className="maindata-label" style={{'fontWeight':'bolder','width':'100%'}}>{filtername == "All"?"Daily Deals":filtername}

 {this.sortComp(Options)}
 </h3>
    </List.Item>

    <List.Item>

<p style={{'color':'red'}}> ({maindata.length}+) found  </p>
    </List.Item>

<List.Item>
{ maindata.length ? 
<ul className="list-view">
{paginatedList.map((e,index)=>(e.agencyname?<Shops key={index} data={e} />: <ListViewRent  history={history} key={index} data={e}></ListViewRent>))}

</ul> :
<Empty description="Not Available">(0) Item(s) found</Empty>}
</List.Item>

</List>
   </Card> 

{!isHome &&
<Pagination pageSize={pagesize}  
showTotal={(e,i)=>("Total "+e + " item(s)")} onChange={(page,pagesize)=>{
this.pageChange(page, pagesize)
}} total={maindata.length} responsive={true} />

}

   </>
    


}

        </div>

      )

    }
  }

  
 
  

  
  
  export default withRouter(connect(mapStateToProps,{setToHome,updateAjaxRoute,dailyDeals,get_current_address,Sort})(MainViewPage))

  MainViewPage.propTypes = {
 
           
      maindata:PropTypes.array.isRequired,
      search:PropTypes.func.isRequired,
      Sort:PropTypes.func.isRequired,
      get_current_address:PropTypes.func.isRequired,
      updateAjaxRoute:PropTypes.func.isRequired,
      routeStatus:PropTypes.bool.isRequired,
      isHome:PropTypes.string.isRequired,
   
     
     
      
  }