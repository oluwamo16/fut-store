import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import {withRouter} from 'react-router-dom'
import "antd/dist/antd.css"
import {Button,Form,Input,Divider, Alert, Row, Col, Checkbox, Modal,Card} from "antd";
import {UserAddOutlined,SecurityScanOutlined, CheckOutlined, UserSwitchOutlined,
	MailOutlined,PhoneOutlined,ShopOutlined} from '@ant-design/icons';
import logo192 from "../../statics/logo512.png";
import {connect} from 'react-redux'
import PropTypes from 'prop-types'
import {signup} from '../../actions/auth'
import "../../css/signup.css"
import "../../css/animate-css/animate.min.css"


  const mapStateToProps= (state, props)=>({
    
        user:state.User
    })


class SignUpApp extends Component{

    constructor(props){
        super(props)
        this.state = {           
            "email":'',
            "password":'',            
            "username":'',
            'store':'',
            "error":false,
            "load":false,
            "require":true,            
            "uploadSuccess":false,
            "tel":'',
         
        }
    }
    

componentWillMount(){

    document.title = "Registration | beBO"    }
    
    onsubmit = (e)=>{
   

            this.setState({...this.state,
                load:!this.state.load})

            const data = {
                user:{}
            }
            data.user.username = this.state.email
             data.user.password = this.state.password
              data.user.email = this.state.email
               data.phone_no = this.state.tel
               data.agencyname = this.state.store
   
                
                this.props.signup(data).then(res=>{
                    // console.log('response: '+res)
                    this.setState({
                        ...this.state, 
                        uploadSuccess:true,
                        load:false,
                      
                    })
                },
                error=>{
                
                // console.log('error: '+error)
                    this.setState({
                        ...this.state,
                load:false,
                error:"E-mail already exists, enter a new email account"
                    })
                })
   
    }
onrequire = ()=>{

    if (this.state.username && this.state.tel && this.state.password && this.state.email ){
      
        this.setState({
            ...this.state,   
    require:false
        })
        

    } else {
        this.setState({
            ...this.state,
    
    error:"All (*) inputs are required",
    require:true
        })
    }
}


    onchange=(e)=>{


        const name = e.target.name
        const value = e.target.value

        

        switch (name) {
            case "username":
                this.setState({
                    ...this.state,
                    username:value
                })
                break;

            case "tel":
                this.setState({
                     ...this.state,
                    tel:value
                })
                break;

            case "email":
                this.setState({
                       ...this.state,
                    email:value
                })
                break;

            case "password":
                this.setState({
                       ...this.state,
                    password:value
                })
                break;


            case "store":
                this.setState({
                       ...this.state,
                    store:value
                })
                break;
        

        
            default:
                break;
        }
        
    }


    render(){

        const {error,load,require} = this.state
        const {history, signup,user} = this.props

        return(

            <div className='page-body' style={{'marginTop':'35px'}}>

<Modal visible={this.state.uploadSuccess} centered title="Registration successful"  okType="primary" okText={
user.authenticated ?<a onClick={e=>this.props.history.push('/logout')}> Logout first and Login to Continue </a> :<a onClick={e=>this.props.history.push('/login')}> Login to Continue </a>

     } cancelText={<a onClick={e=>{e.preventDefault();
      this.props.history.push('/')

    }}
     
     type="ghost">Home </a>}>

<Alert showIcon type="success" message="Signup Successful" ></Alert>
<h2> Login to continue,or go to Home</h2>


            </Modal>


<div className="top">



</div>
                <Row className="row">


<Col className="col site-detail" >


              
<div className="titlepack">
<h1 className='bebotitle'>
Try beBO
        </h1>  
        <h2 className='description'>
        Create your own unique shops online
     
        </h2>

        </div>
             




<ul className="features">
<h1>FEATURES</h1>
<li><CheckOutlined className="check" /> Create your own special shops </li>
<li> <CheckOutlined className="check" /> Bring your product or item online</li>
<li> <CheckOutlined className="check" /> Create your own shop online free and quick.</li>
<li> <CheckOutlined className="check" /> Upload your product or property for sale, rental or exchange</li>

</ul>
</Col>


<Col className="col-signup-form" >





             <Card className="signup-form animated bounceInLeft">
             <h2><UserSwitchOutlined></UserSwitchOutlined> Create new Account for your Shop </h2>

{error ? <Alert showIcon type="error" message={error}></Alert> : <p></p>}


<label htmlFor="agencyname" className='full-name'>Full Name * </label>
<Input name="username" required autoCapitalize  allowClear prefix={<UserAddOutlined></UserAddOutlined>}
onChange={this.onchange} onMouseLeave={e=>this.onrequire} autoFocus autoComplete value={this.state.agencyName} placeholder="Owner Full Name"
/>

 <label htmlFor="store">Shop Name *</label>
<Input name="store" required allowClear  type="text" prefix={<ShopOutlined/>}
onChange={this.onchange} onMouseLeave={e=>this.onrequire} value={this.state.store}  autoComplete="true"  placeholder="ie. Alaba21store electronics, Odeba Food & Beverages, GS Mall etc."
/>

<label htmlFor="email">E-mail *</label>
<Input name="email" required   allowClear prefix={<MailOutlined/>} type="email" 
onChange={this.onchange} onMouseLeave={e=>this.onrequire} 
autoComplete value={this.state.email} placeholder="you@domain.com"
/>


<label htmlFor="tel">Phone Number *</label>
<Input name="tel" required   allowClear prefix={<PhoneOutlined/>} type="tel" 
onChange={this.onchange} onMouseLeave={e=>this.onrequire} 
autoComplete value={this.state.tel} placeholder="08123546778 etc."
/>


<label>Password *</label>

<Input.Password required name="password" onChange={this.onchange} placeholder="Password"
 allowClear prefix={<SecurityScanOutlined></SecurityScanOutlined>}
  value={this.state.password} onMouseLeave={this.onrequire} autoComplete></Input.Password>
  

<div className="terms">

<Checkbox className="check1" required>

    By creating an account, you agree to our Terms of Service and Privacy Policy.
</Checkbox>

<Checkbox className="check2">

    Yes, i would like to receive a monthly e-mail on new item near me
</Checkbox>
</div>

<Divider/>
<div className='btn'>
<Button className="submit" type="primary" loading={load} 
onClick={this.onsubmit}>Continue</Button>



</div>



<Button type="link" className="new-lin" onClick={e=>history.push('/login')}
><h3>Already signed up? Log In</h3></Button>


             </Card>
    
</Col>



                </Row>

             </div>

        )
    }
}

export default withRouter(connect(mapStateToProps,{signup})(SignUpApp))

SignUpApp.propTypes={

    signup:PropTypes.func
}

