
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import {withRouter, Redirect} from 'react-router-dom'
import "antd/dist/antd.css"
import {BASE_URL} from '../../settings'
import {Button,Input, Alert,Card} from "antd";
import {MailOutlined,SecurityScanOutlined, HomeOutlined} from '@ant-design/icons';
import logo192 from "../../statics/logo512.png";

import {connect} from 'react-redux'
import PropTypes from 'prop-types'
import {login, setAuthorizationToken, setUser} from '../../actions/auth'


import "../../css/login.css"
import "../../css/animate-css/animate.min.css"



  const mapStateToProps= (state, props)=>({
    
        user:state.User
    })






class LoginApp extends Component{
constructor(props){
    super(props)
    this.state={
        username:"",
        password:"",
        load:false
    }
}

componentDidMount(){

document.title = "Login | beBO"
}


onsubmit =(e)=> {
this.setState({...this.state,
    load:!this.state.load})


try {
    
    this.props.login(this.state).then(res=>{

    const data = res.data;

    if (data.token){
 
    localStorage.setItem("jwtToken",data.token)
    setAuthorizationToken(data.token);

    this.props.setUser(data.username,true,data.image)
    
   // console.log('token '+data.token)
   //  console.log('username '+data.username)

        // console.log('response '+res)
 this.props.history.push("/")

    } else {

    // console.log('error: '+"Username or password does not match")
         this.setState({
            ...this.state,
    load:false,
    error:"Username or password does not match"
        })

    }

 

}, error=>{

})


} catch (error) {
    this.setState({
        ...this.state,
load:false,
error
    })
}




}

onchange=(e)=>{

const name = e.target.name
const value = e.target.value

if (name=="username"){

    this.setState({
        username:value
    })
    

} else {

    this.setState({
        password:value
    })
}


}

render(){

const {history,login,user} = this.props;
const {load,error} = this.state


    return (

      <div className="login-body" >

      {

        user.authenticated ? 
   
        <Redirect to="/" />
      
      :
        <>
  <div className="login-top">
   


<Button icon={<HomeOutlined></HomeOutlined>} 
type="primary" className="new" onClick={e=>history.push('')}
>Home</Button> 
            
<div className="titlepack">
<h1 className='bebotitle'>
         Log in to <a href={BASE_URL}>beBO</a>
        </h1>  
        <h2 className='description'>
     
     
        </h2>

        </div>
             </div>
         
<div className='grp-form'>



             <Card className="login-form  animated bounceInLeft" >
         


{error ? <Alert showIcon type="error" message={error}></Alert> : <p></p>}

<label htmlFor="username">Email</label>
<Input type="email" name="username"  prefix={<MailOutlined/>} allowClear
onChange={this.onchange}  placeholder="you@domain.com"
/>


<label>Password</label>

<Input.Password name="password" onChange={this.onchange} placeholder="Password"
 allowClear prefix={<SecurityScanOutlined></SecurityScanOutlined>}
  value={this.state.password}></Input.Password>
  


<div className='btn'>
<Button type="primary" loading={load} 
onClick={this.onsubmit}>Continue</Button>

</div>

<Button type="link" className="new-lin" onClick={e=>history.push('/signup')}
><h3>New to beBO? Sign Up </h3></Button>
</Card>

</div>


        </>
      }

      



 
      </div>
    )

}
}





export default withRouter(connect(mapStateToProps,{login,setUser})(LoginApp))

LoginApp.propTypes={

    login:PropTypes.func
}

