
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import {withRouter} from 'react-router-dom'
import BottomNav from "../navigation/bottomnav"
import {connect} from 'react-redux'
import PropTypes from 'prop-types'
import {logout} from '../../actions/auth'
import {setToHome} from '../../actions/contrib'











class LogoutApp extends Component{
componentWillMount(){
	this.props.setToHome(true)
    this.props.logout()
  this.props.history.push('/login')

}

render(){

    return (

      <div>
   
   <BottomNav></BottomNav>
      </div>
    )

}
}





export default withRouter(connect(f=>f,{logout,setToHome})(LogoutApp))

LogoutApp.propTypes={

    logout:PropTypes.func
}

