import React, { Component, useState } from 'react';
import ReactDOM from 'react-dom';

import "antd/dist/antd.css"
import {List,Button,Tabs,Table,Card,Empty, Statistic,Modal,Alert,Form,Input,Avatar,
  Upload,Typography,Row,Col} from "antd";
import {EditOutlined, HomeOutlined,UploadOutlined, ProfileOutlined} from '@ant-design/icons';
import PropTypes from 'prop-types'
import SubmitProperty from "../contrib/submitproperty"
import {BASE_IMG_URL} from '../../settings'



export class ProfileView extends Component{

  constructor(props){
    super(props)
    this.state = {
      modalState:false,
      updateForm:{},
      load:false,
    }
  }
  
handleUpdate=(e,type)=>{

// let data = {...this.state}
// data[type] = e.target.value 

// console.log('update state '+Object.keys(this.state))

switch(type){

  case "tel":{


      this.setState({...this.state,
        'tel':e.target.value
      })

break
  }

    case "agency_name":{


      this.setState({...this.state,
        'agency_name':e.target.value
      })

break
  }

    case "email":{


      this.setState({...this.state,
        'email':e.target.value
      })

break
  }


}




  }

    
handleModal=()=>{


  this.setState({
...this.state,
modalState:!this.state.modalState
  })


}




handleLoad=(data)=>{


  this.setState({
...this.state,
load:data
  })


}

handleupload=(e)=>{

  // console.log('upload click')

  let formdata = new FormData()

if(this.state.images){
  formdata.append('image', this.state.images)
}

if(this.state.email){

formdata.append('email', this.state.email)
}


if(this.state.tel){
formdata.append('tel', this.state.tel)
}

if(this.state.agency_name){
formdata.append('agency_name', this.state.agency_name)
}

formdata.append('username', this.props.data.user.username)

 



  this.setState({
    ...this.state,load:true
})


  this.handleLoad(true);
  this.props.updateProfile(formdata).then(data=>{
    this.handleLoad(false);
    this.handleModal();
  });






}



handleImage=(file,FileList)=>{


const reader = new FileReader()

reader.readAsDataURL(file)



reader.onload=e=>{


  file.thumbUrl=e.target.result
  // console.log("file-single", file)



  this.setState({
    ...this.state,
    images:file
  })


}




}
    


  render(){


  
    const {modalState,updateForm} = this.state

    const {data,history,propertyCount,updateProfile} = this.props



    return (
      data && <>












<Modal visible={modalState} confirmLoading={this.state.load} centered 
title={<span><ProfileOutlined></ProfileOutlined> Update Profile</span>} 
 okType="primary" okText={
<a type="primary" onClick={e=>{
this.handleupload()

}}> Update  </a>

     } cancelText={<a onClick={e=>{e.preventDefault();
      this.handleModal()

    }}
     
     >Cancel Update </a>}>
       
<Form>
<Upload  className='pic-file-picker'  beforeUpload={(file,FileList)=>{this.handleImage(file,FileList); 
  return false}} listType="picture-card" showUploadList>

  <Row>
<p><UploadOutlined style={{"fontSize":"30px", "color":"grey"}}>
    </UploadOutlined></p>
<Col>


</Col>
<Col>

  <p> Drag and drop profile picture to upload</p>
    <p style={{"color":"silver"}}> You can upload your pic here</p>
</Col>

<Col>
    <Button 
type="primary"> SELECT IMAGE</Button>

</Col>

</Row>

</Upload>


<label htmlFor="agency">Agency Name </label>
<Input name="agency" required allowClear 
onChange={e=>this.handleUpdate(e,'agency_name')}  autoComplete="true"  placeholder={data && data.agencyname}
/>


<label htmlFor="email">E-mail </label>
<Input prefix={"@"} name="email" required allowClear 
onChange={e=>this.handleUpdate(e,'email')}  autoComplete="true"  placeholder={data &&data.user.email}
/>


<label htmlFor="tel">Phone No: </label>
<Input prefix={"+234"} name="tel" required allowClear type="tel" 
onChange={e=>this.handleUpdate(e,'tel')}  autoComplete="true"  placeholder={data && data.phone_no}
/>

</Form>


            </Modal>




<List className="prop-list" bordered >

<div style={{"textAlign":"center"}} className='profile-pic'>

<Avatar src={BASE_IMG_URL+data.image} className="profile-img-avatar"><h1 className="profile-img-txt" style={{
  'color':'white'
}}>{data.user.username.slice(0,2)}</h1></Avatar>


<p className='ur-dash' style={{'color':'silver','fontWeight':'normal',
'marginTop':'5px'}}> Your dashboard</p>
<p >
 <Button className='dash-edit-btn' type='primary' onClick={e=>this.handleModal()} icon={<EditOutlined></EditOutlined>}>{data.agencyname} </Button> </p>
</div>

<p className="descr"> Username: </p>
<List.Item className="value" 
actions={[<a ></a>,
]}
>{data.user.username}</List.Item>


<p className="descr"> E-mail: </p>
<List.Item className="value"
actions={[<a ></a>,
]}
>{data.user.email}</List.Item>

<p className="descr"> Phone No: </p>
<List.Item className="value"
actions={[<a ></a>,
]}
>{data.phone_no}</List.Item>
<br/>

<List.Item className="value prop-own" 

>Item(s) Owned: ({propertyCount})</List.Item>


</List>




</>
)

  }
}


ProfileView.propTypes = {

    data:PropTypes.object.isRequired,
    propertyCount:PropTypes.number,
    history:PropTypes.object.isRequired,
    updateProfile:PropTypes.func.isRequired,
}



export class ProfilePropertyList extends Component {

constructor(props){
  super(props)
  this.state={
    updateForm:{},
      load:false,
  }
}

handleLoad=(data)=>{


  this.setState({
...this.state,
load:data
  })


}

handleupload=(e)=>{



  let formdata = new FormData()


if(this.state.email){

formdata.append('email', this.state.email)
}


if(this.state.tel){
formdata.append('tel', this.state.tel)
}

if(this.state.title){
formdata.append('title', this.state.title)
}

if(this.state.instock){
formdata.append('instock', this.state.instock)
}

formdata.append('item id', this.state.editVal.id)

 



  this.setState({
    ...this.state,load:true
})


  this.handleLoad(true);
  this.props.updateItem(formdata).then(data=>{
    this.handleLoad(false);
    // this.handleEditModal();

    this.setState({...this.state,done:true})
  });






}

handleUpdate=(e,type)=>{

// let data = {...this.state}
// data[type] = e.target.value 

// console.log('update state '+Object.keys(this.state))

switch(type){

  case "tel":{


      this.setState({...this.state,
        'tel':e.target.value
      })

break
  }

    case "title":{


      this.setState({...this.state,
        'title':e.target.value
      })

break
  }

    case "email":{


      this.setState({...this.state,
        'email':e.target.value
      })

break
  }

 case "instock":{


      this.setState({...this.state,
        'instock':e.target.value
      })

break
  }

}




  }



handleEditModal=(value)=>{


  this.setState({
...this.state,
editModalState:!this.state.editModalState,
editVal:value
  })


}

filterData = (filter)=>{

    return this.props.data.filter(value=>value.acquire_type===filter)
}


TransformData=(data)=>{


return data.map((value,index)=>{

  return {
key:index,
    image: value.images && <img style={{'width':"75px",'height':'70px'}} src={BASE_IMG_URL+value.images[0].images} />,
    description:<div>   <Typography.Text ellipsis className='descr'  style={{'color':"black"}}>{value.title}</Typography.Text> <br/>  
    <Typography.Text ellipsis className='submit'> {value.category}</Typography.Text>   </div>,
    price:<Statistic value={value.price ? value.price:value.from_price+" - "+value.to_price}></Statistic>,
    views:<Statistic value={value.views}></Statistic>,
    created:<Typography.Text ellipsis className='date'> {value.created.split("T")[0]} </Typography.Text>  ,
    view_link:<> <Button className="dash-btn dash-view-btn" onClick={e=>{
      // this.props.toView(value);
        this.props.history.push('/property/views/'+value.id);  

    }


    } type="ghost">View</Button> <br/>
    <Button className="dash-btn" onClick={e=>{
      this.handleEditModal(value)
        

    }


    } type="primary">Edit <EditOutlined></EditOutlined></Button> </>

}})

}

render(){


    const columns = [
   
        {
            title: 'Image',
            dataIndex: 'image',
            key: 'image',
          },
           {
          title: "Details",
          dataIndex: 'description',
          key: 'description',
        },
        {
          title: 'Price (₦)',
          dataIndex: 'price',
          key: 'price',
        },
        {
          title: 'Views',
          dataIndex: 'views',
          key: 'views',
        },
        {
          title: 'Created',
          dataIndex: 'created',
          key: 'created',
          width:"10px",
          'scroll.x':true
        },
        {
            title: 'Action',
            dataIndex: 'view_link',
            key: 'view_link',
          }
      ];
    
const {editModalState,editVal,done} = this.state;

    return (
<div className="data-list" style={{'minWidth':'100%'}}>

{ editVal ?
<Modal visible={editModalState} confirmLoading={this.state.load} centered 
title={<span> <EditOutlined /> Update Item: <i>{editVal.title}</i></span>} 
 okType="primary" okText={
<a type="primary" onClick={e=>{
this.handleupload()

}}> Update  </a>

     } cancelText={<a onClick={e=>{e.preventDefault();
      this.handleEditModal()

    }}
     
     >Close </a>}>

     { done ? 
<>

<Alert showIcon type="success" message="Update successful" ></Alert>
<p> View to check update </p>
</>

      :

      <Form>



<label htmlFor="title">Item title </label>
<Input name="agency" required allowClear 
onChange={e=>this.handleUpdate(e,'title')}  autoComplete="true"  placeholder={editVal.title}
/>


<label htmlFor="email">Item E-mail Contact </label>
<Input prefix={"@"} name="email" required allowClear 
onChange={e=>this.handleUpdate(e,'email')}  autoComplete="true"  placeholder={editVal.submit_user.user.email}
/>


<label htmlFor="tel">Item Phone No Contact </label>
<Input prefix={"+234"} name="tel" required allowClear type="tel" 
onChange={e=>this.handleUpdate(e,'tel')}  autoComplete="true"  placeholder="eg. 08145435550"
/>

<label htmlFor="tel">Item(s) in stock </label>
<Input name="number" required allowClear type="number" 
onChange={e=>this.handleUpdate(e,'instock')}  autoComplete="true"  placeholder="Edit amount in stock"
/>

</Form>

     }
       


            </Modal>

 :<p></p>}




        <h1 className="prop-submit">Item(s) Owned ({this.props.data.length})  <SubmitProperty /> </h1>

        <Tabs tabPosition="top"  defaultActiveKey="Sale" >


  <Tabs.TabPane key="Sale" tab="SALE(S)" >

  {this.filterData('sale').length ? 
    
    <Table  sortDirections={["ascend","descend"]} tableLayout="auto" 

      dataSource={this.TransformData(this.filterData('sale'))} 
      columns={columns} />
:

<Empty description="No sale(s) data">

</Empty>
}


 
    </Tabs.TabPane>

  <Tabs.TabPane key="Rent" tab="RENTAL(S)" >

  {this.filterData('rent').length ? 
    
    <Table  sortDirections={["ascend","descend"]} tableLayout="auto" 

      dataSource={this.TransformData(this.filterData('rent'))} columns={columns} />
:

<Empty description="No rent(s) data">

</Empty>
}

  </Tabs.TabPane>


    <Tabs.TabPane key="exchange" tab="EXCHANGE(S)" >

  {this.filterData('exchange').length ? 
    
    <Table  sortDirections={["ascend","descend"]} tableLayout="auto" 

      dataSource={this.TransformData(this.filterData('exchange'))} columns={columns} />
:

<Empty description="No exchange(s) data">

</Empty>
}

  </Tabs.TabPane>




</Tabs>


        </div>
    )

}
}


ProfilePropertyList.propTypes = {

    data:PropTypes.array.isRequired,
    history:PropTypes.object.isRequired,
    updateItem:PropTypes.func.isRequired
    
}
