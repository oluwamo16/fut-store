
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import {withRouter} from 'react-router-dom'
import "antd/dist/antd.css"
import {Row,Col,Button} from "antd";
import {HomeOutlined} from '@ant-design/icons';
import {connect} from 'react-redux'
import PropTypes from 'prop-types'

import Home from "../navigation/home"


import {getProfileData,getMyPropertyData,updateProfile,updateItem} from "../../actions/dashboard"
import {ProfileView,ProfilePropertyList} from "../profile/views"
import {toView} from "../../actions/rent_to_view"
import "../../css/dashboard.css"




const mapStateToProps= (state, props)=>({
    
    user:state.User,
    profile:state.DashboardData.profile,
    myProperty:state.DashboardData.myProperty
})




class DashboardApp  extends Component{

    componentWillMount(){

        document.title = this.props.user.username+" | Dashboard"
        
        this.props.getProfileData(this.props.user.username)
        this.props.getMyPropertyData(this.props.user.username)
        }



        
    render(){

        const {profile, myProperty,updateProfile,toView,history,updateItem}=this.props;
        // console.log("profile-dash-data: "+Object.keys(profile))

        return(
<>
           

<div className="dash-row">
<Home type='primary'></Home>
<Button type="link" className="new" onClick={e=>history.push('/submitProperty')}
>New to beBo? Upload Item(s)</Button>

           

           <Row  gutter={[12, 12]}>

               <Col span={5} className="dash-col-1" >
               
              <ProfileView data={profile} updateProfile={updateProfile} history={this.props.history} propertyCount={myProperty ? Object.keys(myProperty).length:0}></ProfileView>
               </Col>


               <Col span={18} className="dash-col-2">
                   <ProfilePropertyList toView={toView} updateItem={updateItem} data={myProperty} history={this.props.history} />
               </Col>

                </Row>
 </div>
        



                </>
        )
    }
}


export default withRouter(connect(mapStateToProps, {updateItem,getProfileData,getMyPropertyData,updateProfile,toView})(DashboardApp))

DashboardApp.propTypes = {

    user:PropTypes.object.isRequired,
    profile:PropTypes.object.isRequired,
    myProperty:PropTypes.array.isRequired,
    getProfileData:PropTypes.func.isRequired,
    getMyPropertyData:PropTypes.func.isRequired,
}
