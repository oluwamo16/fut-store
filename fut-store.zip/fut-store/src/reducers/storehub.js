


export const shubImages = (state = [], action) => {

    switch (action.type) {

        case "ADD_HUB_IMAGE":
            {
                
                return [...state,action.image]
                break;
                


            }


             case "REMOVE_HUB_IMAGE":
            {
                
                return state.filter(e=>e.uid!==action.image.uid)
                
break;

            }


                      case "RESET_HUB_IMAGE":
            {
                
                return []
                
break;

            }


        default:
            return state


    }
}






export const finishLoad= (state = false, action) => {

    switch (action.type) {

        case "SET_FINISH_LOAD":
            {
                
                return action.status
                break;

            }

        default:
            return state


    }
}


export const imgUploadDone= (state = false, action) => {

    switch (action.type) {

        case "SET_IMG_UPLOAD_STAT":
            {
                
                return action.status
                break;

            }

        case "RESET_IMG_UPLOAD_STAT":
            {
                
                return false
                break;

            }

        default:
            return state


    }
}





export const verifyState= (state = false, action) => {

    switch (action.type) {

        case "SET_VERIFY_STATE":
            {
                
                return action.status
                break;

            }

        default:
            return state


    }
}


const defaultState ={

    condition:'new',
    acquire_type:'sale',
    negotiable:'no',
    instock:1,
    delivery:'no',
    payment_type:'Cash, ',
    'delivery_comp':"Other",
    'price':0

}


export const sHubInputs= (state = defaultState, action) => {

    switch (action.type) {

        case "ADD_INPUT":
            {

                const val = {}
                val[action.input_type] = action.input_value


                
                return {...state,
                    ...val}

                break;

            }


            case "RESET_INPUT":
            {

           


                
                return defaultState;

                break;

            }

        default:
            return state


    }
}
