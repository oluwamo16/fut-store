export const toView = (state = {}, action) => {

    switch (action.type) {

        case "SET_TO_VIEW":
            {

                return {
                    data: action.data
                }


            }


        default:
            return state


    }
}