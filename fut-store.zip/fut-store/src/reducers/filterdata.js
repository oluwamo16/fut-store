export const filterData = (state = {}, action) => {

    switch (action.type) {

        case "SET_FILTER_DATA":
            {
                // console.log('profileData: '+action.data)
                return {
                    data: action.data

                }


            }


        default:
            return state


    }
}


export const filterName = (state ="" , action) => {

    switch (action.type) {

        case "SET_FILTER_NAME":
            {
                // console.log('filtername: '+action.data)
                return action.data


            }


        default:
            return state


    }
}



export const filterToggleStat = (state ="" , action) => {

    switch (action.type) {

        case "TOGGLE_FILTER":
            {
                // console.log('filtername: '+action.data)
                return action.data


            }


        default:
            return state


    }
}