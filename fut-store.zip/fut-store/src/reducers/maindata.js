// import {v4} from "uuid"

// import {setCurrentUser} from '../actions/auth'
import logo192 from "../statics/logo192.png"


const defaultData = []



export const MainData = (state = [], action) => {

    switch (action.type) {

        case "SET_MAIN_DATA":
            {

                return [...action.data
                ]


            }
        default:
            return state

    }
}