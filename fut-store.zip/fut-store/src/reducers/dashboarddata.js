


export const DashboardData = (state = {}, action) => {

    switch (action.type) {

        case "SET_PROFILE_DATA":
            {
// console.log('profileData: '+action.data)
                return {...state,profile:action.data}


            }

        case "SET_MY_PROPERTY_DATA":
            {

                return {...state,myProperty:action.data}


            }

        default:
            return state


    }
}