export const searchData = (state ="", action) => {

    switch (action.type) {

        case "SET_SEARCH_PREF":
            {
// console.log('searchpref- '+Object.keys(action.data))
                return action.data ? action.data :""


            }
        default:
            return state


    }
}