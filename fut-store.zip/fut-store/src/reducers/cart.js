export const cartLen= (state = 0, action) => {

    switch (action.type) {

        case "SET_CART_LEN":
            {
                
                return action.value
                break;

            }

        default:
            return state


    }
}