export const ajaxRoute = (state = {}, action) => {

    switch (action.type) {

        case "SET_AJAX":
            {
                // console.log('profileData: '+action.data)
                return {
                   status:action.value
                }


            }


        default:
            return state


    }
}