import {combineReducers} from "redux";
import {User} from "./user"
import {MainData} from "./maindata"
import {DashboardData} from "./dashboarddata"
import {filterData,filterName,filterToggleStat} from "./filterdata"
import {searchData} from "./searchdata"
import {ajaxRoute} from './ajaxroute'
import {toView} from './toview'
import {isHome} from './ishome';
import {cartLen} from './cart';
import {shubImages,finishLoad,imgUploadDone,verifyState,sHubInputs} from './storehub';



export const rootReducer = combineReducers({
    User,MainData,DashboardData,filterData,filterName, 
    searchData,ajaxRoute,toView,isHome,shubImages,finishLoad,imgUploadDone,verifyState,
sHubInputs,filterToggleStat,cartLen})