// import {v4} from "uuid"

// import {setCurrentUser} from '../actions/auth'
const defUser={

username:'Anonymous',
authenticated:false
}




export const User = (state=defUser, action)=>{

    switch(action.type){

        case "SET_CURRENT_USER":{

// console.log("set current image "+action.image)


            return {username:action.username,
            authenticated:action.authenticated,
            pic:action.image
        }


        }
        default:
            return state


    }
}