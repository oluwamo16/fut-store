export const isHome = (state = true, action) => {

    switch (action.type) {

        case "SET_IS_HOME":
            {
                
                return action.value
                


            }


        default:
            return state


    }
}