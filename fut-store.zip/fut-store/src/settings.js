

// export const BASE_URL ="https://bebo-api.herokuapp.com/"
// export const BASE_IMG_URL ="https://bebo-api.herokuapp.com"

export const BASE_URL ="http://127.0.0.1:8000/"
export const BASE_IMG_URL ="http://127.0.0.1:8000"

export const API_SOCKET_URL ="ws://127.0.0.1:8000/ws/"

