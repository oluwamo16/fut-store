import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import {Switch,Route} from "react-router-dom";
import App from "./App"
import TopNav from "./components/navigation/topnav"
import BottomNav from "./components/navigation/bottomnav"
import "antd/dist/antd.css"
import LoginApp from "./components/auth/login"
import LogoutApp from "./components/auth/logout"
import NotFound from "./components/error/notfound"
import SignUpApp from "./components/auth/signup"
import DashboardApp from "./components/profile/dashboard"
import requireAuth2 from "./components/contrib/requireAuth2";
import {PrivateRoute} from "./components/contrib/requireAuth";
import SubmitPropertyForm from "./components/contrib/submitpropertyform"
import PopularShop from "./components/contrib/popular-shop"
import ToViewData from './components/contrib/toviewdata'
import Cart from './components/contrib/cart'
import UploadDone from './components/contrib/upload-done'
import store from './store';




const BaseApp=({})=>{

return (

<>
  


  <TopNav></TopNav>


<Route exact path="/" component={App} />
<Route exact path="/login" component={LoginApp} />
<PrivateRoute isAuthenticated={store.getState().User.authenticated} path='/logout' component={LogoutApp} />
<Route exact path="/dashboard" component={requireAuth2(DashboardApp)} />
<Route exact path="/popular-shop" component={PopularShop} />
<Route exact path="/submitProperty" component={requireAuth2(SubmitPropertyForm)} />
<Route exact path="/cart/:username" component={requireAuth2(Cart)} />
<Route exact path="/upload_notification" component={requireAuth2(UploadDone)} />

<Route exact path="/signup" component={SignUpApp} />

<Route exact path="/property/views/:id" component={ToViewData} />

<BottomNav></BottomNav>



</>






	)

}


export default BaseApp;