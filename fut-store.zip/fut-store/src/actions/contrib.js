
import axios from 'axios';

import {BASE_URL} from '../settings'





export function uploadProperty(userData){
    return dispatch => {

return axios.post(BASE_URL+"upload_property/", userData,{
	headers:{
		'content-type':'multipart/form-data'
	}
});

    }
}



export function setToHome(value) {
    // console.log("filter-name "+filterName)
    return {
        type: "SET_IS_HOME",
      value
        
    }
}

