
import {updateAjaxRoute} from './ajaxroute'
import {setMainData} from './search'
import {sortBy,reverse} from 'lodash'




export function Sort(maindata,sortFilter){




	return dispatch=>{

 dispatch(updateAjaxRoute(true))
var sortData = [];

// console.log('sort -- '+Object.keys(maindata)) 


if(sortFilter=='na'){

      sortData= reverse(sortBy(maindata,['id']))
  
  } else if (sortFilter=='pl2h'){

     sortData= sortBy(maindata,['price','from_price'])
  } 
  else if (sortFilter=='ph2l'){

     sortData= reverse(sortBy(maindata,['price','from_price']))
  }

  else if (sortFilter=='sr'){

     sortData= reverse(sortBy(maindata,[o=>o.submit_user.rate_count]))
  }
else if (sortFilter=='r'){

     sortData= reverse(sortBy(maindata,[o=>o.submit_user.rate]))
  }

  else if (sortFilter=='il'){

     sortData= reverse(sortBy(maindata,'likes'))
  }









		     // console.log('sort -- '+Object.keys(sortData)) 
  
    dispatch(setMainData(sortData));
    dispatch(updateAjaxRoute(false))
	}
}