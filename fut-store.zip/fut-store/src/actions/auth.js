
import axios from 'axios';

import jwtDecode from "jwt-decode"


import {BASE_URL} from '../settings'

export function setAuthorizationToken(token){

if(token){

    axios.defaults.headers.common["Authorization"] = "Token<"+token+">";

}
 else {

    delete axios.defaults.headers.common["Authorization"]
 }
}



export function signup(userData){
    return dispatch => {

return axios.post(BASE_URL+"signup/", userData);

    }
}



export function logout(){

    return dispatch=>{
        
        localStorage.removeItem("jwtToken");
        setAuthorizationToken(false);
        dispatch(setCurrentUser("Anonymous",false));
        


    }
}


export function login(data){

    return dispatch=>{

return axios.post(BASE_URL+"login/",data)

    }
}



export function setUser(username,authenticated,image){

    return dispatch=>{

        dispatch(setCurrentUser(username,authenticated,image));


    }
}








export function setCurrentUser(username,authenticated,image){

    return {
        type:"SET_CURRENT_USER",
        username,
        authenticated,
        image
    }

}