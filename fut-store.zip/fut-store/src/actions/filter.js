
import {setSearchPref} from "./search"
import {uniq} from 'lodash'

var filterName="Home"


function transformToFilter(data,filter){

// var mapData = data.map(value=>value[filter])
var mapData = ()=>{

    var returnData=["All"];

    Object.keys(data).forEach(
        prop =>  returnData.push(data[prop][filter]));

    return returnData
}


// console.log("mapdata-filter-> "+ mapData())

let uniqueData = ['All']

// for(let x=0; x < mapData().length; x++){

//     if(! (mapData()[x] in uniqueData) ){
//         uniqueData.push(mapData()[x])

//         }
// }

// console.log("uniquefilter-> "+uniqueData)
return uniq(mapData())

}


export function setFilter(data,filter = "category") {

    return dispatch => {
        // filterName=filtername
        
        return dispatch(setFilterData(transformToFilter(data,filter)))

    }

}

export function setFilterData(data) {
    // console.log("filter-name "+filterName)
    return {
        type: "SET_FILTER_DATA",
        data
        
    }
}


export function setFilterName(data) {
    // console.log("filter-name "+data)
    return {
        type: "SET_FILTER_NAME",
        data
        
    }
}


export function setFilterToggle(data) {
    // console.log("filter-name "+data)
    return {
        type: "TOGGLE_FILTER",
        data
        
    }
}





export const handleFilterClick=(props,state,type="")=>{

    const {filterTag, searchFilterVal, filterSearch } = props
    


props.setToHome && props.setToHome(false);

    props.updateAjaxRoute(true)
    document.title='beBO - '+ (state.filtername ? state.filtername: state.click)
  
const dataValue = {
    search:state.search?state.search:searchFilterVal,
      location:props.get_current_address(),
       type:type,
      value:state.priceVal ? state.priceVal:state.click,
      filtername:state.filtername ? state.filtername:state.click,
      category:state.category
     
    }

            filterSearch(dataValue)
              // this.props.setFilter(this.props.mainData,"title",this.state.click)

    
}

