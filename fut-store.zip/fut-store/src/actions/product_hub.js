import {API_SOCKET_URL} from '../settings'


export function uploadSocket(username) {

    return dispatch => {

const upload= new WebSocket(API_SOCKET_URL+'upload/'+String(username)+'/')




  return upload;



      

    }

}