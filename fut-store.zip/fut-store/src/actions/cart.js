

import axios from 'axios';

import {BASE_URL} from '../settings'



export function getCart(username) {
    
    return dispatch => {


        return axios.get(BASE_URL+"getcart/"+username)

    }

}

export function getCartLen(username) {
    
    return dispatch => {


        return axios.get(BASE_URL+"getcartlen/"+username)

    }

}



export function addItemToCart(id,username) {
    
    return dispatch => {


        return axios.get(BASE_URL+"addtocart/"+id+'/'+username)

    }

}


export function removeFromCart(cartId,itemId) {
    
    return dispatch => {


        return axios.get(BASE_URL+"removefromcart/"+cartId+'/'+itemId)

    }

}


export function cartRecommend(data) {
    
    return dispatch => {


        return axios.post(BASE_URL+"cartrecommend/",data)

    }

}


export function setCartLen(value){

return {
    type:"SET_CART_LEN",
    value
}
}
