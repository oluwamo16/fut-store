
import axios from 'axios';

import {BASE_URL} from '../settings'



export function addHubImage(image){

    return {

        type:"ADD_HUB_IMAGE",
        image

    }
}



export function removeHubImage(image){

    return {

        type:"REMOVE_HUB_IMAGE",
        image

    }
}



export function resetHubImage(){

    return {

        type:"RESET_HUB_IMAGE"

    }
}


export function setFinishLoad(status){

    return {

        type:"SET_FINISH_LOAD",
        status

    }
}


export function setImgUploadStat(status){

    return {

        type:"SET_IMG_UPLOAD_STAT",
        status

    }
}


export function resetImgUploadStat(status){

    return {

        type:"RESET_IMG_UPLOAD_STAT",
        status

    }
}


export function setVerifyState(status){

    return {

        type:"SET_VERIFY_STATE",
        status

    }
}



export function add_inputs(input_type, input_value){

    return {

        type:"ADD_INPUT",
        input_type, 
        input_value

    }
}

export function reset_inputs(status){

    return {

        type:"RESET_INPUT",
        status

    }
}



export function uploadStoreItem(data) {

    return async dispatch => {

        return await axios.post(BASE_URL + "store/upload/", data,{
    headers:{
        'content-type':'multipart/form-data'
    }
})

        // return dispatch(setProfileData(defaultData.profile));

    }

}
