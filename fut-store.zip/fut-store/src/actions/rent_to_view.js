

import axios from 'axios';

import {BASE_URL} from '../settings'



export function toView(id) {
    
    return dispatch => {


        return axios.get(BASE_URL+"toview/"+id)

    }

}




export function addView(id) {
    
    return dispatch => {


        return axios.get(BASE_URL+"addview/"+id)

    }

}
export function youMayLike(category,id) {
    
    return dispatch => {


        return axios.get(BASE_URL+"youmaylike/"+category+'/'+id)

    }

}



export function addLike(id) {
    
    return dispatch => {


        return axios.get(BASE_URL+"addlike/"+id)

    }

}

export function addRate(id,value) {
    
    return dispatch => {


        return axios.get(BASE_URL+"addrate/"+id+'/'+value)

    }

}


export function addReview(id,data,username) {
    
    return dispatch => {


        return axios.post(BASE_URL+"addreview/"+id+'/'+username+'/',{'text':data})

    }

}



export function setToViewStatus(data) {
// console.log('toview data '+data)
    return {
        type: "SET_TO_VIEW",
        data:data
    }
}