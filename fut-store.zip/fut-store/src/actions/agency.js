
import axios from 'axios';


import {BASE_URL} from '../settings'


export function getTopCompany(){
     return dispatch => {


        return axios.get(BASE_URL+"getTopCompany")

    }
}
