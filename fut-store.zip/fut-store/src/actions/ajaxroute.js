export function updateAjaxRoute(value) {

    return dispatch => {


        return dispatch(setAjaxStatus(value))

    }

}

export function setAjaxStatus(value) {

    return {
        type: "SET_AJAX",
        value,
    }
}