import axios from 'axios';
import {address} from "./location"
import {updateAjaxRoute} from './ajaxroute'
import {setToHome} from './contrib'
import {setFilterName} from './filter'
import {BASE_URL} from '../settings'


import logo192 from "../statics/logo192.png"


const defaultData = [{
    "title":"Shared 3 Bedroom Flat",
    'address':"No 64, Adetoku street, Onabanjo",
    'price':90000,
    'acquire_type':"rent",
    "duration":"Yearly",
    "dur_count":4,
    "id":1,
    "views":56,
    "images":[logo192,logo192,logo192],
    "email":"Agency@e.com",
    'tel':'08034547888',
    "account":{
        "username":"Oluwamo",
"email":"Agency@e.com",
'phone_no':'08034547888'
},

    "description":"good goodgoodgoodgoodgood goodgoodgoodgoodgoodgood",
    "location":"Oluwabanjo adeniji, Lagos",
    "category":"Apartment",
    "requirement":"good goodgoodgoodgoodgood goodgoodgoodgoodgoodgood",
    



},
{
    "title":"Shared 3 Bedroom Flat",
    'address':"No 64, Adetoku street, Onabanjo",
    'price':129070,
    'acquire_type':"rent",
    "duration":"Yearly",
    "dur_count":4,
    "id":2,
    "views":56,
    "images":[logo192,logo192,logo192],
    "email":"Agency@e.com",
    'tel':'08034547888',
    "account":{
        "username":"Oluwamo",
"email":"Agency@e.com",
'phone_no':'08034547888'
},

    "description":"good goodgoodgoodgoodgood goodgoodgoodgoodgoodgood",
    "location":"Oluwabanjo adeniji, Lagos",
    "category":"Vehicle",
    "requirement":"good goodgoodgoodgoodgood goodgoodgoodgoodgoodgood",
    



},]



const defaultSearchPref = {

    search:"",
    filter:[{
        name:"location",
        value:address()
    },]
    
    }

    


export function getSuggestion(data){
     return dispatch => {


        return axios.post(BASE_URL+"getsuggestion/",data)

    }
}




export function dailyDeals(data){

return dispatch=> {
   
   return axios.post(BASE_URL+"mainsearch/",data).then(res=>{

    const result = res.data;

    
    dispatch(setSearchPref(''))
    dispatch(setMainData(result));
    dispatch(updateAjaxRoute(false))
dispatch(setFilterName("Daily Deals"))
   }).then(err=>{

       console.log("error - "+err)
       
   })



}

}





export function search(data){

return dispatch=> {
    const newSearch =data
   return axios.post(BASE_URL+"mainsearch/",newSearch).then(res=>{

    const result = res.data;

  dispatch(setToHome(false))
    dispatch(setSearchPref(newSearch.search))
    dispatch(setMainData(result));
    dispatch(updateAjaxRoute(false))

   }).then(err=>{

       console.log("error - "+err)
       
   })



}

}



export function filterSearch(data){
    
    return dispatch=> {
        
        const searchData = {
search:data.search,
location:data.location,
value:data.value,
category:data.category
        }


 


       return axios.post(BASE_URL+data.type+"/",searchData).then(res=>{
    
        const result = res.data;

        dispatch(setSearchPref(data.search))
        dispatch(setMainData(result));
        dispatch(updateAjaxRoute(false))

        dispatch(setFilterName(data.filtername))

       }).then(err=>{
    
           console.log("error - "+err)
           
       })
    
    }
    
    }

    



export function getCategory() {
    
    return dispatch => {


        return axios.get(BASE_URL+"getcategory")

    }

}


export function setMainData(data){

return {
    type:"SET_MAIN_DATA",
    data
}
}




export function setSearchPref(data){

    return {

        type:"SET_SEARCH_PREF",
        data: data

    }
}