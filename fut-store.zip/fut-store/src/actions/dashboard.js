import axios from 'axios';
import logo192 from "../statics/logo192.png";
import {setCurrentUser} from './auth'

import {BASE_URL} from '../settings'


const defaultData = {
    "profile": {
        "username":"Oluwamo",
"email":"Agency@e.com",
'phone_no':'08034547888',
'image':logo192,
'agency_name':"Gks Estate"
},



    "myProperty": [{
        "title":"Shared 3 Bedroom Flat",
        'address':"No 64, Adetoku street, Onabanjo",
        'price':90000,
        'acquire_type':"rent",
        "duration":"Yearly",
        "dur_count":4,
        "id":1,
        "views":56,
        "images":[logo192,logo192,logo192],
        "email":"Agency@e.com",
        'tel':'08034547888',
        "account":{
            "username":"Oluwamo",
    "email":"Agency@e.com",
    'phone_no':'08034547888'
   },
    
        "description":"good goodgoodgoodgoodgood goodgoodgoodgoodgoodgood",
        "location":"Oluwabanjo adeniji, Lagos",
        "category":"Apartment",
        "requirement":"good goodgoodgoodgoodgood goodgoodgoodgoodgoodgood",
        'created':"27 AUG, 2018"
        
    
    
    
    },]
}


export function getProfileData(user) {

    return dispatch => {

        return axios.get(BASE_URL + "dashboard/profile/"+user+'/').then(res => {
// console.log("connect profile- " + Object.keys(res.data))
            const data = res.data;

            dispatch(setProfileData(data));
          


        }).then(err => {

            console.log("error - " + err)

        })


        // return dispatch(setProfileData(defaultData.profile));

    }

}




export function setProfileData(data) {

    return {
        type: "SET_PROFILE_DATA",
        data
    }
}


export function getMyPropertyData(user) {

      return dispatch => {

        return axios.get(BASE_URL + "dashboard/myproperty/"+user+'/').then(res => {
// console.log("profile-property " + Object.keys(res.data))
            const data = res.data;
            

            dispatch(setMyPropertyData(data));
          


        }).then(err => {

            console.log("error - " + err)

        })


         // return  dispatch(setMyPropertyData(defaultData.myProperty));

    }
       

    

}




export function setMyPropertyData(data) {

    return {
        type: "SET_MY_PROPERTY_DATA",
        data
    }
}




export function updateProfile(data) {

    return dispatch => {

        return axios.post(BASE_URL + "dashboard/updateprofile/", data,{
    headers:{
        'content-type':'multipart/form-data'
    }
}).then(res => {

            const data = res.data;
// console.log("update "+Object.keys(data))

            dispatch(setCurrentUser(data.user.username,true,data.image))
            dispatch(setProfileData(data));

         


        }).then(err => {

            console.log("error - " + err)

        })


        // return dispatch(setProfileData(defaultData.profile));

    }

}




export function updateItem(data) {

    return dispatch => {

        return axios.post(BASE_URL + "dashboard/updateitem/", data).then(res => {

            const data = res.data;
// console.log("update "+Object.keys(data))

            // dispatch(setCurrentUser(data[0].submit_user.user.username,true,data[0].submit_user.image))
            // dispatch(setProfileData(data));

         


        }).then(err => {

            console.log("error - " + err)

        })


        // return dispatch(setProfileData(defaultData.profile));

    }

}


