
import {createStore, applyMiddleware} from 'redux';
import {rootReducer} from './reducers'
import thunk from "redux-thunk";




const saver = store=>next=>action=>{

  switch(action.type){
    case("REMOVE_TODO"):
    // console.log(
    //     'Remove '+action.id+'- and props data send online '+"with props ("+action.id+')')
    
      }
    
  let result = next(action);
  localStorage['beboapp-store'] = JSON.stringify(store.getState())

  return  result;
}



const store = applyMiddleware(thunk,saver)(createStore)(rootReducer,(
localStorage['beboapp-store'] ? JSON.parse(localStorage['beboapp-store']):{}
))


export default store