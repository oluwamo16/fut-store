process.env.NODE_ENV = "production"; 
process.env.BABEL_ENV="production"; 

require('./server/bootstrap');